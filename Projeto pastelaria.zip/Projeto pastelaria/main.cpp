#include <iostream> /*incluir o conte�do do arquivo de cabe�alho chamado iostream, 
que fornece funcionalidades de entrada/sa�da padr�o. Isso habilita o uso de recursos essenciais, 
como cin para entrada padr�o e cout para sa�da padr�o no programa C++.*/

#include <string> /*incluir o conte�do do cabe�alho "string", 
que � parte da biblioteca padr�o do C++. Esse cabe�alho fornece funcionalidades para manipula��o, cria��o e opera��es em strings.*/

#include <fstream> /*A inclus�o do cabe�alho <fstream> em C++ permite o uso de classes como ifstream para leitura, ofstream para escrita, 
e fstream para opera��es de leitura e escrita em arquivos. 
Este cabe�alho, parte da biblioteca padr�o do C++, fornece funcionalidades essenciais para opera��es de entrada e sa�da de arquivos, 
oferecendo uma interface conveniente para manipula��o de arquivos no C++.*/


#include <locale> /*Essa biblioteca padr�o oferece classes e fun��es para ajustar opera��es conforme o ambiente local, 
como a formata��o de n�meros, datas e horas de acordo com conven��es culturais e regionais. 
A inclus�o de <locale> � �til em aplica��es que requerem suporte para m�ltiplos idiomas e desejam adaptar a apresenta��o de dados conforme as prefer�ncias do 
usu�rio ou o contexto regional.*/


using namespace std; /*O namespace std cont�m classes e fun��es padr�o da biblioteca C++, como cout, cin, string, entre outras. 
Ao incluir essa declara��o, todos os elementos do namespace std tornam-se automaticamente dispon�veis no escopo atual do c�digo, 
evitando a necessidade de escrever std:: antes de cada refer�ncia a uma fun��o ou classe do namespace padr�o.*/

struct Pastel {
    string tipo;
    int quantidade;
    int quantidadeDesejada; 
    Pastel* proximo;

    Pastel(const string& _tipo, int _quantidade, int _quantidadeDesejada) 
        : tipo(_tipo), quantidade(_quantidade), quantidadeDesejada(_quantidadeDesejada), proximo(NULL) {}
        //struct Pastel {: Inicia a defini��o da estrutura chamada Pastel. A estrutura � uma forma de agrupar diferentes tipos de dados sob um �nico nome.//
        
		//string tipo;: Declara uma vari�vel membro chamada tipo do tipo string. Essa vari�vel armazenar� o tipo do pastel.
        
		//double(numeros com partesfracion�rias) quantidade;: Declara uma vari�vel membro chamada quantidade do tipo double. Essa vari�vel armazenar� a quantidade do pastel.
        
		//int(N�meros inteiros) quantidadeDesejada;: Adiciona uma vari�vel membro chamada quantidadeDesejada do tipo int. Essa vari�vel representa a quantidade desejada do pastel.//
        
		//Pastel* proximo;: Declara um ponteiro para outra estrutura Pastel chamado proximo. Esse ponteiro ser� usado para criar uma lista encadeada de objetos Pastel.
        
		/*Pastel(const string& _tipo, double _quantidade, int _quantidadeDesejada) 
		: tipo(_tipo), quantidade(_quantidade), quantidadeDesejada(_quantidadeDesejada), proximo(NULL) {}: 
		Define um construtor para a estrutura Pastel. Este construtor recebe par�metros para inicializar os membros da estrutura. 
		A inicializa��o � feita atrav�s de uma lista de inicializa��o. O ponteiro proximo � inicializado como NULL.*/
		
		//Lista encadeada
};



struct Bebida {
    string tipo;
    double quantidade;
    Bebida* proxima;

    Bebida(const string& _tipo, double _quantidade) : tipo(_tipo), quantidade(_quantidade), proxima(NULL) {}
    /*struct Bebida {: Inicia a defini��o da estrutura chamada Bebida. A estrutura � uma forma de agrupar diferentes tipos de dados sob um �nico nome.*/
    
	//string tipo;: Declara uma vari�vel membro chamada tipo do tipo string. Essa vari�vel armazenar� o tipo da bebida.
    
	//double quantidade;: Declara uma vari�vel membro chamada quantidade do tipo double. Essa vari�vel armazenar� a quantidade da bebida.
    
	//Bebida* proxima;: Declara um ponteiro para outra estrutura Bebida chamado proximo. Esse ponteiro ser� usado para criar uma lista encadeada de objetos Bebida.
    
	/*Bebida(const string& _tipo, double _quantidade) : tipo(_tipo), quantidade(_quantidade), proxima(NULL) {}: 
	Define um construtor para a estrutura Bebida. Este construtor recebe par�metros para inicializar os membros da estrutura. 
	A inicializa��o � feita atrav�s de uma lista de inicializa��o. O ponteiro proximo � inicializado como NULL.*/
};




struct Pedido {
    int senha;
    string nomeCliente;
    Pastel* primeiroPastel;
    Bebida* primeiraBebida;
    Pedido* proximo;
    bool entregue;

    Pedido(int _senha, const string& _nomeCliente) : senha(_senha), nomeCliente(_nomeCliente),
                                                     primeiroPastel(NULL), primeiraBebida(NULL),
                                                     proximo(NULL), entregue(false) {}
//struct Pedido { Inicia a defini��o da estrutura chamada Pedido. Uma estrutura � uma forma de agrupar diferentes tipos de dados sob um �nico nome.

//int senha; Declara uma vari�vel membro chamada senha, que � do tipo int. Essa vari�vel armazenar� a senha associada ao pedido.

//string nomeCliente;: Declara uma vari�vel membro chamada nomeCliente, que � do tipo string. Essa vari�vel armazenar� o nome do cliente associado ao pedido.

/*Pastel* primeiroPastel; Declara um ponteiro chamado primeiroPastel que aponta para uma estrutura Pastel. 
Este ponteiro ser� usado para criar uma lista encadeada de objetos Pastel associados ao pedido.*/

/*Bebida* primeiraBebida; Declara um ponteiro chamado primeiraBebida que aponta para uma estrutura Bebida. 
Este ponteiro ser� usado para criar uma lista encadeada de objetos Bebida associados ao pedido.*/

/*Pedido* proximo; Declara um ponteiro chamado proximo que aponta para a pr�xima estrutura Pedido na sequ�ncia. 
Este ponteiro ser� usado para criar uma lista encadeada de pedidos.*/

/*bool(avaliam condi��es que podem ser verdadeiras ou falsas) entregue; Declara uma vari�vel membro chamada entregue, que � do tipo bool. 
Essa vari�vel ser� utilizada para indicar se o pedido foi entregue ou n�o.*/

/*Pedido(int _senha, const string& _nomeCliente(declara uma refer�ncia constante para uma string chamada _nomeCliente.)) : 
senha(_senha), inicializa o membro senha da estrutura Pedido com o valor passado como _senha para o construtor 
nomeCliente(_nomeCliente), 
primeiroPastel(NULL), 
primeiraBebida(NULL), 
proximo(NULL), 
entregue(false) {}: 

Define um construtor para a estrutura Pedido. Este construtor recebe par�metros para inicializar os membros da estrutura. 
A inicializa��o � feita atrav�s de uma lista de inicializa��o. O ponteiro primeiroPastel e primeiraBebida s�o inicializados como NULL, 
indicando que inicialmente n�o h� past�is nem bebidas associados ao pedido. O ponteiro proximo � inicializado como NULL, indicando que inicialmente n�o h� pedido seguinte na sequ�ncia. 
A vari�vel entregue � inicializada como false, indicando que o pedido ainda n�o foi entregue.*/


   void adicionarPastel(const string& tipo, int quantidade, int quantidadeDesejada) {
    primeiroPastel = new Pastel(tipo, quantidade, quantidadeDesejada);
}
/*void adicionarPastel(const string& tipo, int quantidade, int quantidadeDesejada) {: Esta linha define a fun��o chamada adicionarPastel. 
A fun��o n�o retorna nenhum valor (void). Ela recebe tr�s par�metros: tipo (uma string), quantidade (um n�mero inteiro) 
e quantidadeDesejada (um n�mero inteiro).*/

/*primeiroPastel = new Pastel(tipo, quantidade, quantidadeDesejada);: Esta linha cria dinamicamente um novo objeto da classe (ou estrutura) Pastel 
usando o operador new. Os valores dos par�metros tipo, quantidade, e quantidadeDesejada s�o passados para o construtor de Pastel.
new Pastel(...): Aloca dinamicamente espa�o na mem�ria para um novo objeto Pastel.*/

/*Pastel(tipo, quantidade, quantidadeDesejada): Chama o construtor da classe Pastel para inicializar os membros do novo objeto com os valores fornecidos.*/

/*O ponteiro primeiroPastel � ent�o atualizado para apontar para o novo objeto Pastel criado. Isso sugere que primeiroPastel est� sendo usado para manter uma 
lista encadeada de objetos Pastel.*/
    
	
	
	void adicionarBebida(const string& tipo, int quantidade) {
        primeiraBebida = new Bebida(tipo, quantidade);
    }
/*void adicionarBebida(const string& tipo, int quantidade) {: Esta linha define a fun��o chamada adicionarBebida. 
A fun��o n�o retorna nenhum valor (void). Ela recebe dois par�metros: tipo (uma string) e quantidade (um n�mero de ponto flutuante).*/

/*primeiraBebida = new Bebida(tipo, quantidade);: Esta linha cria dinamicamente um novo objeto da classe (ou estrutura) Bebida usando o operador new. 
Os valores dos par�metros tipo e quantidade s�o passados para o construtor de Bebida.*/

/*new Bebida(...): Aloca dinamicamente espa�o na mem�ria para um novo objeto Bebida.*/

/*Bebida(tipo, quantidade): Chama o construtor da classe Bebida para inicializar os membros do novo objeto com os valores fornecidos.*/

/*O ponteiro primeiraBebida � ent�o atualizado para apontar para o novo objeto Bebida criado. 
Isso sugere que primeiraBebida est� sendo usado para manter uma lista encadeada de objetos Bebida.*/ 
	
	
	void marcarComoEntregue() {
        entregue = true;
    }
};
/*void marcarComoEntregue() {: Esta linha define a fun��o chamada marcarComoEntregue. A fun��o n�o retorna nenhum valor (void). 
Ela n�o recebe nenhum par�metro, indicando que a marca��o como entregue � realizada sem a necessidade de informa��es adicionais.*/

//entregue = true; Esta linha atualiza o valor do membro de dados entregue para true. � uma maneira de indicar que o pedido foi entregue.

/*Portanto, a fun��o marcarComoEntregue � respons�vel por modificar o estado do objeto da classe ou estrutura (provavelmente um pedido) 
para indicar que o pedido foi entregue. A vari�vel membro entregue � marcada como true para representar essa condi��o.*/


struct PedidoProducao {
    int senha;
    Pedido* pedido;
    PedidoProducao* proximo;

    PedidoProducao(int _senha, Pedido* _pedido) : senha(_senha), pedido(_pedido), proximo(NULL) {}
};
/*struct PedidoProducao {: Inicia a defini��o da estrutura chamada PedidoProducao. A estrutura � uma forma de agrupar diferentes tipos de dados sob um �nico nome.
int senha;: Declara uma vari�vel membro chamada senha do tipo int. Essa vari�vel armazenar� a senha associada ao pedido de produ��o.*/

/*Pedido* pedido;: Declara um ponteiro chamado pedido que aponta para uma estrutura Pedido. 
Este ponteiro ser� usado para referenciar um objeto Pedido associado ao pedido de produ��o.*/

/*PedidoProducao* proximo;: Declara um ponteiro chamado proximo que aponta para a pr�xima estrutura PedidoProducao na sequ�ncia. 
Este ponteiro ser� usado para criar uma lista encadeada de pedidos de produ��o.*/

/*PedidoProducao(int _senha, Pedido* _pedido) : senha(_senha), pedido(_pedido), proximo(NULL) {}: Define um construtor para a estrutura PedidoProducao. 
Este construtor recebe dois par�metros para inicializar os membros da estrutura. A inicializa��o � feita atrav�s de uma lista de inicializa��o. 
O ponteiro proximo � inicializado como NULL.*/


struct EstoqueMateriasPrimas {
    double queijo;
    double presunto;
    double frango;

    EstoqueMateriasPrimas() : queijo(50000.0), presunto(20000.0), frango(10000.0) {}
};
/*struct EstoqueMateriasPrimas {: Inicia a defini��o da estrutura chamada EstoqueMateriasPrimas. 
A estrutura � uma forma de agrupar diferentes tipos de dados sob um �nico nome.*/

/*double queijo;, double presunto;, double frango;: Declara tr�s vari�veis membros do tipo double chamadas queijo, presunto e frango. 
Essas vari�veis armazenar�o as quantidades dispon�veis de queijo, presunto e frango no estoque de mat�rias-primas.*/

/*EstoqueMateriasPrimas() : queijo(50000.0), presunto(20000.0), frango(10000.0) {}: Define um construtor para a estrutura EstoqueMateriasPrimas. 
Este construtor � chamado quando um objeto EstoqueMateriasPrimas � criado. 
Na lista de inicializa��o do construtor, as vari�veis queijo, presunto e frango s�o inicializadas com os valores espec�ficos fornecidos.*/

/*queijo(50000.0): Inicializa a vari�vel queijo com o valor 50000.0.
presunto(20000.0): Inicializa a vari�vel presunto com o valor 20000.0.
frango(10000.0): Inicializa a vari�vel frango com o valor 10000.0.*/



class BarracaPastel {
public: /* � usada para definir a se��o de membros de uma classe que � acess�vel a partir de fora da pr�pria classe.*/
    BarracaPastel() : primeiroPedido(NULL), ultimoPedido(NULL), primeiroProducao(NULL), ultimoProducao(NULL),
                      proximaSenha(1), totalCocaColaVendidas(0), totalPepsiVendidas(0),
                      totalPastelFrangoPedidos(0), totalPastelQueijoPedidos(0), totalPastelPizzaPedidos(0),
                      totalPastelVentoPedidos(0), totalPastelQueijoVendidos(0), totalPastelFrangoVendidos(0),
                      totalPastelPizzaVendidos(0), totalPastelVentoVendidos(0) {}

/*BarracaPastel() : primeiroPedido(NULL), ultimoPedido(NULL), primeiroProducao(NULL), ultimoProducao(NULL), 
proximaSenha(1), totalCocaColaVendidas(0), totalPepsiVendidas(0), totalPastelFrangoPedidos(0), totalPastelQueijoPedidos(0), 
totalPastelPizzaPedidos(0), totalPastelVentoPedidos(0), totalPastelQueijoVendidos(0), totalPastelFrangoVendidos(0), 
totalPastelPizzaVendidos(0), totalPastelVentoVendidos(0) {} */

/*primeiroPedido(NULL), ultimoPedido(NULL): Inicializa dois ponteiros para objetos da classe Pedido chamados primeiroPedido e ultimoPedido. 
Esses ponteiros provavelmente est�o sendo usados para criar e gerenciar uma lista encadeada de pedidos.*/      

/*primeiroProducao(NULL), ultimoProducao(NULL): Inicializa dois ponteiros para objetos da classe PedidoProducao chamados primeiroProducao e ultimoProducao. 
Da mesma forma, esses ponteiros provavelmente est�o sendo usados para criar e gerenciar uma lista encadeada de pedidos de produ��o.*/  

/*proximaSenha(1): Inicializa uma vari�vel chamada proximaSenha com o valor 1. 
Essa vari�vel provavelmente est� sendo usada para atribuir senhas consecutivas aos pedidos.*/ 

/*totalCocaColaVendidas(0), totalPepsiVendidas(0): Inicializa duas vari�veis chamadas totalCocaColaVendidas e totalPepsiVendidas com o valor 0. 
Essas vari�veis podem ser usadas para acompanhar a quantidade total de Coca-Cola e Pepsi vendidas.*/   

/*totalPastelFrangoPedidos(0), totalPastelQueijoPedidos(0), totalPastelPizzaPedidos(0), totalPastelVentoPedidos(0): 
Inicializa quatro vari�veis que provavelmente est�o sendo usadas para acompanhar o n�mero total de pedidos de diferentes tipos de pasteis.*/

/*totalPastelQueijoVendidos(0), totalPastelFrangoVendidos(0), totalPastelPizzaVendidos(0), totalPastelVentoVendidos(0): 
Inicializa quatro vari�veis que provavelmente est�o sendo usadas para acompanhar o n�mero total de pasteis vendidos de diferentes tipos.*/

/*Essa lista de inicializa��o est� configurando o estado inicial dos membros da classe BarracaPastel quando um objeto dessa classe � criado. 
A utiliza��o dessas vari�veis e ponteiros sugere que a classe est� sendo utilizada para gerenciar pedidos, 
produ��o e estat�sticas relacionadas a uma barraca de venda de pasteis.*/
                      
                      

    Pedido* getPrimeiroPedido() const {
        return primeiroPedido;
    }

/*Pedido* getPrimeiroPedido() const {: Esta linha define a fun��o getPrimeiroPedido.
Getters s�o m�todos de acesso que s�o projetados para obter (ou "pegar") o valor de um atributo privado de uma classe ou estrutura. 
Eles s�o usados para expor informa��es encapsuladas de forma controlada e segura.
A fun��o � projetada para fornecer acesso ao membro de dados primeiroPedido de uma inst�ncia da classe BarracaPastel. 
Isso � feito retornando um ponteiro para o objeto da classe Pedido associado ao primeiro pedido na lista encadeada de pedidos mantida pela barraca de pasteis.
a escolha do nome getPrimeiroPedido() sugere que a fun��o � projetada para "obter" o primeiro pedido na lista de pedidos da barraca de pasteis. 
Esse padr�o de nomenclatura ajuda a tornar o c�digo mais leg�vel e compreens�vel.*/

//Pedido*: Indica que a fun��o retorna um ponteiro para um objeto da classe Pedido.

//getPrimeiroPedido(): Este � o nome da fun��o.

//const: Indica que a fun��o n�o modificar� nenhum membro da classe. Ou seja, � uma fun��o constante, que pode ser chamada em objetos constantes da classe sem alterar seu estado interno.
    
//{ return primeiroPedido; }: O corpo da fun��o consiste em uma �nica instru��o que retorna o valor do membro de dados primeiroPedido.
	
	
	const EstoqueMateriasPrimas& getEstoque() const {
        return estoque;
    }
    /*const EstoqueMateriasPrimas&: Indica que o tipo de retorno da fun��o � uma refer�ncia constante para um objeto da classe EstoqueMateriasPrimas. 
	A refer�ncia constante (const) impede a modifica��o do objeto referenciado.
	&: � utilizado como operador de endere�o. Ele � usado para obter o endere�o de uma vari�vel na mem�ria. Por exemplo, se x � uma vari�vel, &x representa o endere�o*/ 
	
	/*getEstoque() const {: Define a fun��o chamada getEstoque. A fun��o � constante (const no final) para indicar que ela n�o modifica o estado 
	interno do objeto ao qual ela pertence.*/
	
	/*{ return estoque; }: O corpo da fun��o consiste em uma �nica instru��o que retorna a refer�ncia constante para o membro de dados estoque da classe 
	� qual esta fun��o pertence.*/
    
    
	
	
	void excluirPedido(int senha) {
        Pedido* atual = primeiroPedido;
        Pedido* anterior = NULL;

        while (atual && atual->senha != senha) {
            anterior = atual;
            atual = atual->proximo;
        }

        if (atual) {
            if (anterior) {
                anterior->proximo = atual->proximo;
                if (atual == ultimoPedido) {
                    ultimoPedido = anterior;
                }
            } else {
                primeiroPedido = atual->proximo;
                if (!primeiroPedido) {
                    ultimoPedido = NULL;
                }
            }

            limparPastels(atual->primeiroPastel);
            limparBebidas(atual->primeiraBebida);
            delete atual;

            cout << "Pedido exclu�do com sucesso.\n";
        } else {
            cout << "Pedido n�o encontrado.\n";
        }
    }
    /*Pedido* atual = primeiroPedido;: Inicializa um ponteiro chamado atual apontando para o primeiro pedido na lista encadeada.*/
    
    /*Pedido* anterior = NULL;: Inicializa um ponteiro chamado anterior como NULL. 
	Esse ponteiro ser� usado para rastrear o n� anterior ao n� que est� sendo avaliado durante a busca pelo pedido com a senha fornecida.*/
	
	/*while (atual && atual->senha != senha) { ... }: Um loop while que percorre a lista encadeada de pedidos at� encontrar um pedido com a senha correspondente ou 
	chegar ao final da lista. O ponteiro anterior � atualizado para apontar para o n� anterior a atual a cada itera��o.
	� uma palavra-chave utilizada em v�rias linguagens de programa��o para criar um loop, ou seja, 
	um bloco de c�digo que � repetidamente executado enquanto uma condi��o espec�fica � verdadeira.
	|
	A ideia � que o c�digo dentro das chaves {} � repetidamente executado enquanto a condi��o especificada ap�s a palavra-chave 
	while for avaliada como verdadeira. A condi��o � verificada antes de cada execu��o do bloco de c�digo. Se a condi��o for falsa, 
	o loop � encerrado e a execu��o continua ap�s o bloco while.*/
	
	/*if (atual) { ... } else { ... }: Verifica se um pedido com a senha fornecida foi encontrado. 
	Se n�o for encontrado, exibe uma mensagem informando que o pedido n�o foi encontrado.*/
	
	/*if (anterior) { ... } else { ... }: Dentro do bloco do if (atual), verifica se anterior � NULL ou n�o. 
	Se n�o for NULL, significa que atual n�o � o primeiro n� da lista, e o ponteiro do n� anterior � atualizado para ignorar atual. 
	Se anterior for NULL, significa que atual � o primeiro n� da lista, e o ponteiro do primeiro n� � atualizado.*/
	
	/*limparPastels(atual->primeiroPastel);: Chama uma fun��o limparPastels para liberar a mem�ria associada aos past�is do pedido. 
	Ela libera a mem�ria alocada para os past�is associados ao pedido.*/
	
	/*limparBebidas(atual->primeiraBebida);: Chama uma fun��o limparBebidas para liberar a mem�ria associada �s bebidas do pedido. 
	A implementa��o espec�fica dessa fun��o n�o est� fornecida, mas ela provavelmente libera a mem�ria alocada para as bebidas associadas ao pedido.*/
	
	/*delete atual;: Libera a mem�ria alocada para o n� do pedido atual.
	delete(ele � usado para desalocar a mem�ria que foi previamente alocada durante a execu��o do programa.)*/
	
	/*cout << "Pedido exclu�do com sucesso.\n";: Exibe uma mensagem indicando que o pedido foi exclu�do com sucesso.
	cout(� um objeto associado � sa�da padr�o em C++ e � utilizado para realizar opera��es de sa�da no console. 
	Ele faz parte da biblioteca de entrada/sa�da padr�o (iostream) em C++)*/
	
	/*cout << "Pedido n�o encontrado.\n";: Exibe uma mensagem indicando que o pedido n�o foi encontrado.*/
    
    /*Essa fun��o realiza a exclus�o de um pedido com base na senha fornecida, ajustando corretamente os ponteiros na lista encadeada 
	e liberando a mem�ria associada aos past�is e bebidas do pedido.*/
    

    
	void cadastrarPedido() {
    string nomeCliente;
    cout << "Nome do Cliente: ";
    cin >> nomeCliente;

    Pedido* novoPedido = new Pedido(proximaSenha++, nomeCliente);

    adicionarPastel(novoPedido);
    adicionarBebida(novoPedido);

    if (!primeiroPedido) {
        primeiroPedido = novoPedido;
        ultimoPedido = novoPedido;
    } else {
        ultimoPedido->proximo = novoPedido;
        ultimoPedido = novoPedido;
    }

    cout << "Pedido cadastrado com sucesso. Senha do Pedido: " << novoPedido->senha << "\n";
}
/*string nomeCliente;: Declara uma vari�vel do tipo string chamada nomeCliente para armazenar o nome do cliente.*/

/*cout << "Nome do Cliente: ";: Exibe uma mensagem no console solicitando ao usu�rio que insira o nome do cliente.*/

/*cin >> nomeCliente;: L� o nome do cliente da entrada padr�o (teclado) e o armazena na vari�vel nomeCliente.
cin(realiza opera��es de entrada)*/

/*Pedido* novoPedido = new Pedido(proximaSenha++, nomeCliente);: Aloca dinamicamente um novo objeto da classe Pedido, utilizando o operador new. 
O construtor da classe Pedido � chamado, inicializando o novo pedido com uma senha �nica (incrementada a partir de proximaSenha) e o nome do cliente fornecido.*/

//adicionarPastel(novoPedido);: Chama uma fun��o adicionarPastel que permite ao usu�rio selecionar e adicionar past�is ao pedido. 

//adicionarBebida(novoPedido);: Chama uma fun��o adicionarBebida que permite ao usu�rio selecionar e adicionar bebidas ao pedido. 

/*if (!primeiroPedido) { ... } else { ... }: Verifica se primeiroPedido � NULL (ou seja, se n�o h� nenhum pedido registrado ainda). 
Se n�o houver, configura primeiroPedido e ultimoPedido para apontar para o novo pedido. Se j� houver, 
atualiza o ponteiro proximo do �ltimo pedido para apontar para o novo pedido e atualiza ultimoPedido para o novo pedido.*/

/*cout << "Pedido cadastrado com sucesso. Senha do Pedido: " << novoPedido->senha << "\n";: 
Exibe uma mensagem informando que o pedido foi cadastrado com sucesso e mostra a senha associada ao novo pedido.*/

/*Essa fun��o realiza o processo de cadastro de um novo pedido, interagindo com o usu�rio para obter informa��es sobre o cliente, 
adicionando past�is e bebidas ao pedido, e mantendo a lista encadeada de pedidos atualizada.*/

    
	
	
	void listarPedidos() const {
        cout << "Lista de Pedidos:\n";
        Pedido* atual = primeiroPedido;
        while (atual) {
            mostrarDetalhesPedido(atual);
            atual = atual->proximo;
        }
        cout << endl;
    }
    //Essa fun��o listarPedidos tem como objetivo exibir detalhes de todos os pedidos cadastrados.
	
	/*Essa fun��o percorre a lista encadeada de pedidos, exibindo detalhes de cada pedido usando a fun��o mostrarDetalhesPedido. 
	Essa abordagem � �til para apresentar uma vis�o geral dos pedidos armazenados no sistema.*/
	
	/*cout << "Lista de Pedidos:\n";: Exibe uma mensagem indicando que a lista de pedidos ser� apresentada.*/
	
	/*Pedido* atual = primeiroPedido;: Inicializa um ponteiro chamado atual que aponta para o primeiro pedido na lista encadeada.*/
	
	/*while (atual) { ... }: Inicia um loop while que percorre a lista encadeada de pedidos. 
	O loop continua enquanto atual n�o for NULL, indicando que ainda h� pedidos a serem processados.*/
	
	/*mostrarDetalhesPedido(atual);: Chama uma fun��o chamada mostrarDetalhesPedido para exibir detalhes do pedido apontado por atual. 
	Ela exibe informa��es como a senha do pedido, o nome do cliente, os past�is e as bebidas associados a esse pedido.*/
	
	/*atual = atual->proximo;: Atualiza o ponteiro atual para apontar para o pr�ximo pedido na lista encadeada. Isso move o loop para o pr�ximo pedido.*/
	
	/*cout << endl;: Adiciona uma linha em branco ap�s a listagem dos pedidos para melhorar a formata��o na sa�da.*/
	
	

    
	
	void marcarPedidoComoEntregue(int senha) {
        Pedido* atual = primeiroPedido;
        Pedido* anterior = NULL;

        while (atual && atual->senha != senha) {
            anterior = atual;
            atual = atual->proximo;
        }

        if (atual) {
            if (!atual->entregue) {
                atual->entregue = true;
                atualizarEstoquePedido(atual->primeiroPastel);
                atualizarContadoresVenda(atual->primeiroPastel);
                cout << "Pedido marcado como entregue e removido da lista com sucesso.\n";
            } else {
                cout << "Este pedido j� foi entregue anteriormente.\n";
            }

            // Remove o pedido da lista
            if (anterior) {
                anterior->proximo = atual->proximo;
                if (atual == ultimoPedido) {
                    ultimoPedido = anterior;
                }
            } else {
                primeiroPedido = atual->proximo;
                if (!primeiroPedido) {
                    ultimoPedido = NULL;
                }
            }

            limparPastels(atual->primeiroPastel);
            limparBebidas(atual->primeiraBebida);
            delete atual;
        } else {
            cout << "Pedido n�o encontrado.\n";
        }
    }
    
/*Pedido* atual = primeiroPedido;: Inicializa um ponteiro chamado atual que aponta para o primeiro pedido na lista encadeada.*/

/*Pedido* anterior = NULL;: Inicializa um ponteiro chamado anterior como NULL. 
Esse ponteiro ser� usado para rastrear o n� anterior ao n� que est� sendo avaliado durante a busca pelo pedido com a senha fornecida.*/

/*while (atual && atual->senha != senha) { ... }: Um loop while que percorre a lista encadeada de pedidos at� encontrar um pedido com a senha correspondente ou chegar ao final da lista. 
O ponteiro anterior � atualizado para apontar para o n� anterior a atual a cada itera��o.
&& � um operador l�gico em v�rias linguagens de programa��o, incluindo C++, C#, Java e outras. Este operador � conhecido como "AND l�gico" e � usado para combinar duas condi��es. 
A express�o A && B avalia como verdadeira (true) somente se tanto A quanto B forem verdadeiros.
!= � um operador de compara��o em v�rias linguagens de programa��o, a express�o A && B avalia como verdadeira (true) somente se tanto A quanto B forem verdadeiros.*/

/*if (atual) { ... } else { ... }: Verifica se um pedido com a senha fornecida foi encontrado. 
Se n�o for encontrado, exibe uma mensagem informando que o pedido n�o foi encontrado.*/

/*if (!atual->entregue) { ... } else { ... }: Dentro do bloco if (atual), verifica se o pedido j� foi marcado como entregue (entregue � true). 
Se n�o tiver sido entregue, executa o bloco interno. Se j� foi entregue, exibe uma mensagem informando que o pedido j� foi entregue anteriormente.*/

/*atual->entregue = true;: Marca o pedido como entregue, atribuindo true ao membro entregue do objeto Pedido.*/

/*atualizarEstoquePedido(atual->primeiroPastel);: Chama uma fun��o atualizarEstoquePedido para atualizar o estoque com base nos past�is do pedido.*/

/*atualizarContadoresVenda(atual->primeiroPastel);: Chama uma fun��o atualizarContadoresVenda para atualizar contadores relacionados �s vendas com base nos past�is do pedido.*/

/*cout << "Pedido marcado como entregue e removido da lista com sucesso.\n";: Exibe uma mensagem indicando que o pedido foi marcado como entregue e removido com sucesso.*/

/*if (anterior) { ... } else { ... }: Dentro do bloco do if (atual), verifica se anterior � NULL. Se n�o for NULL, 
significa que atual n�o � o primeiro n� da lista, e o ponteiro do n� anterior � atualizado para ignorar atual. 
Se anterior for NULL, significa que atual � o primeiro n� da lista, e o ponteiro do primeiro n� � atualizado.*/

/*limparPastels(atual->primeiroPastel);: Chama uma fun��o limparPastels para liberar a mem�ria associada aos past�is do pedido.*/

/*limparBebidas(atual->primeiraBebida);: Chama uma fun��o limparBebidas para liberar a mem�ria associada �s bebidas do pedido.*/

/*delete atual;: Libera a mem�ria alocada para o n� do pedido atual.*/

/*} else { cout << "Pedido n�o encontrado.\n"; }: Exibe uma mensagem indicando que o pedido n�o foi encontrado, 
caso o loop n�o tenha encontrado um pedido correspondente � senha.*/

/*Essa fun��o realiza v�rias opera��es associadas � entrega de um pedido, incluindo a marca��o como entregue, atualiza��es nos estoques e contadores, 
remo��o da lista encadeada e libera��o de mem�ria associada ao pedido.*/
    
	
	
	void editarPedido(int senha) {
        Pedido* atual = primeiroPedido;

        while (atual && atual->senha != senha) {
            atual = atual->proximo;
        }

        if (atual) {
            cout << "Nome do Cliente: " << atual->nomeCliente << "\n";

            if (atual) {
                cout << "Novo tipo de Pastel (Pizza, Queijo, Frango, Vento): ";
                cin >> atual->primeiroPastel->tipo;

                editarBebida(atual->primeiraBebida);

                cout << "Pedido editado com sucesso.\n";
            } else {
                cout << "Pedido n�o encontrado.\n";
            }
        }
    }
/*Pedido* atual = primeiroPedido;: Inicializa um ponteiro chamado atual que aponta para o primeiro pedido na lista encadeada.*/

/*while (atual && atual->senha != senha) { ... }: Um loop while que percorre a lista encadeada de pedidos at� encontrar um pedido com a senha 
correspondente ou chegar ao final da lista.*/

/*if (atual) { ... }: Verifica se um pedido com a senha fornecida foi encontrado. Se n�o for encontrado, exibe uma mensagem informando que o pedido n�o foi encontrado.*/

/*cout << "Nome do Cliente: " << atual->nomeCliente << "\n";: Exibe o nome do cliente associado ao pedido encontrado.*/

/*if (atual) { ... } else { ... }: Dentro do bloco if (atual), verifica novamente se atual � diferente de NULL. Se for diferente de NULL, 
continua com a edi��o do pedido. Se for NULL, exibe uma mensagem indicando que o pedido n�o foi encontrado.*/

/*cout << "Novo tipo de Pastel (Pizza, Queijo, Frango, Vento): ";: Exibe uma mensagem solicitando ao usu�rio que insira um novo tipo de pastel.*/

/*cin >> atual->primeiroPastel->tipo;: L� o novo tipo de pastel da entrada padr�o e o armazena no membro tipo do primeiro pastel associado ao pedido.*/

/*editarBebida(atual->primeiraBebida);: Chama uma fun��o editarBebida para editar as informa��es sobre as bebidas associadas ao pedido. 
A implementa��o espec�fica dessa fun��o n�o est� fornecida.*/

/*cout << "Pedido editado com sucesso.\n";: Exibe uma mensagem indicando que o pedido foi editado com sucesso.*/

/*} else { cout << "Pedido n�o encontrado.\n"; }: Exibe uma mensagem indicando que o pedido n�o foi encontrado, caso o loop n�o tenha encontrado um pedido correspondente � senha.*/

/*Essa fun��o permite ao usu�rio editar o tipo de pastel e outras informa��es associadas a um pedido espec�fico com base na senha fornecida.*/

/*O operador -> � conhecido como operador de seta e � usado para acessar membros de um objeto por meio de um ponteiro para esse objeto. 
� uma forma abreviada de acessar membros quando voc� est� lidando com ponteiros para objetos.
EX: ponteiroParaObjeto->meuMembro = 55;*/



    
	
	
	~BarracaPastel() {
        limparPedidos();
    }
/*A fun��o ~BarracaPastel() � um destrutor da classe BarracaPastel em C++. O destrutor � um m�todo especial que � chamado automaticamente quando um objeto sai do 
escopo ou � explicitamente deletado. Ele � usado para realizar tarefas de limpeza, desaloca��o de recursos ou execu��o de outras opera��es necess�rias 
antes que o objeto seja destru�do.*/

/*~BarracaPastel(): Esta � a assinatura do destrutor da classe BarracaPastel. O til (~) precedendo o nome da classe indica que � um destrutor.*/

/*{: In�cio do bloco de c�digo do destrutor.*/

/*limparPedidos();: Chama a fun��o limparPedidos(). Parece ser uma fun��o definida em algum lugar que realiza a limpeza ou desaloca��o de recursos 
associados aos pedidos na barraca de past�is.*/

/*}: Fim do bloco de c�digo do destrutor.*/

/*Essa implementa��o espec�fica do destrutor indica que, ao destruir um objeto do tipo BarracaPastel, a fun��o limparPedidos() 
ser� chamada para realizar alguma opera��o de limpeza relacionada aos pedidos associados � barraca de past�is. 
O objetivo � garantir que os recursos sejam liberados adequadamente e que n�o haja vazamento de mem�ria ou outros problemas associados aos pedidos.*/


private:
    Pedido* primeiroPedido;
    Pedido* ultimoPedido;
    PedidoProducao* primeiroProducao;
    PedidoProducao* ultimoProducao;
    int proximaSenha;
    EstoqueMateriasPrimas estoque;
    int totalCocaColaVendidas;
    int totalPepsiVendidas;
    int totalPastelFrangoPedidos;
    int totalPastelQueijoPedidos;
    int totalPastelPizzaPedidos;
    int totalPastelVentoPedidos;
    int totalPastelQueijoVendidos;
    int totalPastelFrangoVendidos;
    int totalPastelPizzaVendidos;
    int totalPastelVentoVendidos;
/*private � um modificador de acesso que � utilizado em uma classe para especificar que os membros declarados como private s�o acess�veis somente dentro 
da pr�pria classe. Ou seja, eles n�o podem ser acessados diretamente fora da classe ou por classes derivadas.*/

/*Pedido* primeiroPedido; e Pedido* ultimoPedido;: Dois ponteiros que representam o in�cio e o fim de uma lista encadeada de pedidos. 
primeiroPedido aponta para o primeiro pedido na lista, e ultimoPedido aponta para o �ltimo pedido.*/

/*PedidoProducao* primeiroProducao; e PedidoProducao* ultimoProducao;: Dois ponteiros que representam o in�cio e o fim de uma lista encadeada de pedidos de 
produ��o. primeiroProducao aponta para o primeiro pedido de produ��o na lista, e ultimoProducao aponta para o �ltimo pedido de produ��o.*/

/*int proximaSenha;: Uma vari�vel inteira que armazena o valor da pr�xima senha a ser atribu�da a um novo pedido. Parece ser usada para garantir a unicidade das senhas.*/

/*EstoqueMateriasPrimas estoque;: Um objeto da classe EstoqueMateriasPrimas que armazena informa��es sobre o estoque de mat�rias-primas na barraca de past�is.*/

/*int totalCocaColaVendidas;, int totalPepsiVendidas;: Contadores de vendas para produtos espec�ficos, como Coca-Cola e Pepsi.*/

/*int totalPastelFrangoPedidos;, int totalPastelQueijoPedidos;, int totalPastelPizzaPedidos;, int totalPastelVentoPedidos;: 
Contadores de pedidos para diferentes tipos de past�is.*/

/*int totalPastelQueijoVendidos;, int totalPastelFrangoVendidos;, int totalPastelPizzaVendidos;, int totalPastelVentoVendidos;: 
Contadores de vendas para diferentes tipos de past�is.*/


    void adicionarPastel(Pedido* pedido) {
    string tipo;
    double quantidade;
    int quantidadeDesejada;

    cout << "Tipo de Pastel (Pizza, Queijo, Frango, Vento): ";
    cin >> tipo;

    cout << "Quantidade desejada de Pastel: ";
    cin >> quantidadeDesejada;

    cout << "Quantidade do Pastel por unidade: ";
    cin >> quantidade;

    if (verificarEstoque(tipo, quantidade * quantidadeDesejada)) {
        for (int i = 0; i < quantidadeDesejada; ++i) {
            pedido->adicionarPastel(tipo, quantidade, quantidadeDesejada);
        }
        atualizarEstoque(tipo, quantidade * quantidadeDesejada);

        // Incrementar os contadores de quantidade vendida
        if (tipo == "Queijo") {
            totalPastelQueijoVendidos += quantidadeDesejada;
        } else if (tipo == "Frango") {
            totalPastelFrangoVendidos += quantidadeDesejada;
        } else if (tipo == "Pizza") {
            totalPastelPizzaVendidos += quantidadeDesejada;
        } else if (tipo == "Vento") {
            totalPastelVentoVendidos += quantidadeDesejada;
        }
    } else {
        cout << "Pedido n�o cadastrado devido a estoque insuficiente.\n";
    }
}
/*string tipo;, double quantidade;, int quantidadeDesejada;: Declara��o de vari�veis locais para armazenar o tipo de pastel, 
a quantidade por unidade e a quantidade desejada pelo cliente.*/

/*cout << "Tipo de Pastel (Pizza, Queijo, Frango, Vento): ";, cin >> tipo;: Solicita ao usu�rio que insira o tipo de pastel desejado e l� a entrada correspondente.*/

/*cout << "Quantidade desejada de Pastel: ";, cin >> quantidadeDesejada;: Solicita ao usu�rio que insira a quantidade desejada de past�is e l� a entrada correspondente.*/

/*cout << "Quantidade do Pastel por unidade: ";, cin >> quantidade;: Solicita ao usu�rio que insira a quantidade do pastel por unidade e l� a entrada correspondente.*/

/*if (verificarEstoque(tipo, quantidade * quantidadeDesejada)) {: Verifica se h� estoque suficiente para o tipo e quantidade desejada de past�is.*/

/*for (int i = 0; i < quantidadeDesejada; ++i) { pedido->adicionarPastel(tipo, quantidade, quantidadeDesejada); }: Adiciona past�is ao pedido. 
A fun��o adicionarPastel � chamada no objeto pedido para adicionar o tipo, quantidade e quantidade desejada ao pedido.*/

/*atualizarEstoque(tipo, quantidade * quantidadeDesejada);: Atualiza o estoque subtraindo a quantidade de past�is adicionados.*/

/*if (tipo == "Queijo") { totalPastelQueijoVendidos += quantidadeDesejada; } else if ...: Incrementa os contadores de quantidade vendida para o tipo espec�fico de pastel. 
Isso ajuda a rastrear as estat�sticas de vendas.*/

/*} else { cout << "Pedido n�o cadastrado devido a estoque insuficiente.\n"; }: Se o estoque n�o for suficiente para atender ao pedido, 
exibe uma mensagem informando ao usu�rio que o pedido n�o foi cadastrado devido ao estoque insuficiente.*/

/*Essa fun��o coleta informa��es do usu�rio sobre o tipo e a quantidade desejada de past�is, verifica se h� estoque suficiente, adiciona past�is ao pedido, 
atualiza o estoque e incrementa os contadores de quantidade vendida, se aplic�vel. Em caso de estoque insuficiente, informa ao usu�rio que o pedido n�o foi cadastrado.*/

    
	
	void adicionarBebida(Pedido* pedido) {
        string tipo;
        double quantidade;

        cout << "Tipo de Bebida (Coca-Cola ou Pepsi): ";
        cin >> tipo;

        cout << "Quantidade da Bebida (em ml): ";
        cin >> quantidade;

        pedido->adicionarBebida(tipo, quantidade);
    }
/*string tipo;, double quantidade;: Declara��o de vari�veis locais para armazenar o tipo de bebida e a quantidade desejada pelo cliente.*/

/*cout << "Tipo de Bebida (Coca-Cola ou Pepsi): ";, cin >> tipo;: Solicita ao usu�rio que insira o tipo de bebida desejada e l� a entrada correspondente.*/

/*cout << "Quantidade da Bebida (em ml): ";, cin >> quantidade;: Solicita ao usu�rio que insira a quantidade desejada de bebida em mililitros e l� a entrada correspondente.*/

/*pedido->adicionarBebida(tipo, quantidade);: Chama a fun��o adicionarBebida no objeto pedido para adicionar a bebida ao pedido, passando o tipo e a quantidade como argumentos.*/

/*Essa fun��o coleta informa��es do usu�rio sobre o tipo e a quantidade desejada de bebida e, em seguida, 
adiciona essa bebida ao pedido utilizando a fun��o adicionarBebida do objeto pedido.
Essa abordagem encapsula a l�gica de adi��o de bebidas dentro da classe Pedido.
A fun��o adicionarBebida da classe Pedido trata internamente a cria��o e o gerenciamento de objetos de bebida associados ao pedido.*/
    
    
    

    void limparPedidos() {
        Pedido* atual = primeiroPedido;
        while (atual) {
            Pedido* proximo = atual->proximo;
            limparPastels(atual->primeiroPastel);
            limparBebidas(atual->primeiraBebida);
            delete atual;
            atual = proximo;
        }
        primeiroPedido = ultimoPedido = NULL;
    }
/*Pedido* atual = primeiroPedido;: Inicializa um ponteiro atual apontando para o primeiro pedido na lista encadeada.*/

/*while (atual) { ... }: Inicia um loop while que percorre a lista encadeada de pedidos at� que o ponteiro atual seja NULL (indicando o final da lista).*/

/*Pedido* proximo = atual->proximo;: Armazena o ponteiro para o pr�ximo pedido na lista antes de deletar o pedido atual. 
Isso � feito para evitar perda de refer�ncias ap�s a dele��o.*/   

/*limparPastels(atual->primeiroPastel);: Chama uma fun��o limparPastels para limpar os past�is associados ao pedido atual. 
A implementa��o espec�fica dessa fun��o n�o foi fornecida.*/

/*limparBebidas(atual->primeiraBebida);: Chama uma fun��o limparBebidas para limpar as bebidas associadas ao pedido atual. 
A implementa��o espec�fica dessa fun��o n�o foi fornecida.*/

/*delete atual;: Desaloca a mem�ria do pedido atual.*/

/*atual = proximo;: Move o ponteiro atual para o pr�ximo pedido na lista.*/

/*primeiroPedido = ultimoPedido = NULL;: Define os ponteiros primeiroPedido e ultimoPedido como NULL, indicando que a lista de pedidos agora est� vazia.*/

/*Essa fun��o percorre a lista encadeada de pedidos, limpa os past�is e bebidas associados a cada pedido, desaloca a mem�ria do pedido e, finalmente, 
redefine os ponteiros primeiroPedido e ultimoPedido para indicar uma lista vazia. 
Isso � �til para liberar todos os recursos alocados dinamicamente para os pedidos e evitar vazamentos de mem�ria.*/
    
    

    void limparPastels(Pastel* primeiro) {
        Pastel* atual = primeiro;
        while (atual) {
            Pastel* proximo = atual->proximo;
            delete atual;
            atual = proximo;
        }
    }
/*Pastel* atual = primeiro;: Inicializa um ponteiro atual apontando para o primeiro pastel na lista encadeada de past�is.*/

/*while (atual) { ... }: Inicia um loop while que percorre a lista encadeada de past�is at� que o ponteiro atual seja NULL (indicando o final da lista).*/

/*Pastel* proximo = atual->proximo;: Armazena o ponteiro para o pr�ximo pastel na lista antes de deletar o pastel atual. 
Isso � feito para evitar perda de refer�ncias ap�s a dele��o.*/

/*delete atual;: Desaloca a mem�ria do pastel atual.*/

/*atual = proximo;: Move o ponteiro atual para o pr�ximo pastel na lista.*/

/*Essa fun��o percorre a lista encadeada de past�is associados a um pedido, desaloca a mem�ria de cada pastel e, finalmente, 
libera todos os recursos alocados dinamicamente para os past�is. Isso � �til para garantir que n�o haja vazamento de mem�ria e para limpar os 
past�is quando necess�rio, como ao limpar um pedido ou ao desalocar a mem�ria associada a uma lista de past�is.*/
    
    
    
    void limparBebidas(Bebida* primeira) {
        Bebida* atual = primeira;
        while (atual) {
            Bebida* proxima = atual->proxima;
            delete atual;
            atual = proxima;
        }
    }
/*Bebida* atual = primeira;: Inicializa um ponteiro atual apontando para a primeira bebida na lista encadeada de bebidas.*/

/*while (atual) { ... }: Inicia um loop while que percorre a lista encadeada de bebidas at� que o ponteiro atual seja NULL (indicando o final da lista).*/

/*Bebida* proxima = atual->proxima;: Armazena o ponteiro para a pr�xima bebida na lista antes de deletar a bebida atual. 
Isso � feito para evitar perda de refer�ncias ap�s a dele��o. */   

/*delete atual;: Desaloca a mem�ria da bebida atual.*/

/*atual = proxima;: Move o ponteiro atual para a pr�xima bebida na lista.*/

/*essa fun��o percorre a lista encadeada de bebidas associadas a um pedido, desaloca a mem�ria de cada bebida e, finalmente, 
libera todos os recursos alocados dinamicamente para as bebidas. Isso � �til para garantir que n�o haja vazamento de mem�ria e para limpar as 
bebidas quando necess�rio, como ao limpar um pedido ou ao desalocar a mem�ria associada a uma lista de bebidas.*/


    

    void mostrarDetalhesPedido(const Pedido* pedido) const {
    cout << "Senha: " << pedido->senha << ", Cliente: " << pedido->nomeCliente << "\n";

    Pastel* atualPastel = pedido->primeiroPastel;
    Bebida* atualBebida = pedido->primeiraBebida;

    while (atualPastel || atualBebida) {
        if (atualPastel) {
            cout << "Tipo: " << atualPastel->tipo << ", Quantidade: " << atualPastel->quantidade
                 << ", Quantidade Desejada: " << atualPastel->quantidadeDesejada << "\n";

            // Mostrar os ingredientes do pastel
            mostrarIngredientesPastel(atualPastel->tipo);

            atualPastel = atualPastel->proximo;
        }

            if (atualBebida) {
                cout << "Bebida: " << atualBebida->tipo << ", Quantidade: " << atualBebida->quantidade << "ml\n";
                atualBebida = atualBebida->proxima;
            }
        }

        cout << "------------------------\n";
    }
/*cout << "Senha: " << pedido->senha << ", Cliente: " << pedido->nomeCliente << "\n";: Imprime a senha e o nome do cliente associados ao pedido.*/

/*Pastel* atualPastel = pedido->primeiroPastel;, Bebida* atualBebida = pedido->primeiraBebida;: Inicializa ponteiros para o primeiro pastel e a primeira bebida associados ao pedido.*/

/*while (atualPastel || atualBebida) { ... }: Inicia um loop while que continua enquanto houver past�is ou bebidas a serem processados.*/

/*if (atualPastel) { ... }: Verifica se h� um pastel atual para processar.
cout << "Tipo: " << atualPastel->tipo << ", Quantidade: " << atualPastel->quantidade << ", Quantidade Desejada: " << atualPastel->quantidadeDesejada << "\n";: Imprime detalhes sobre o pastel, incluindo o tipo, a quantidade e a quantidade desejada.
mostrarIngredientesPastel(atualPastel->tipo);: Chama uma fun��o mostrarIngredientesPastel para exibir os ingredientes do pastel com base no tipo. A implementa��o espec�fica dessa fun��o n�o foi fornecida.
atualPastel = atualPastel->proximo;: Move o ponteiro para o pr�ximo pastel na lista.*/

/*if (atualBebida) { ... }: Verifica se h� uma bebida atual para processar.
cout << "Bebida: " << atualBebida->tipo << ", Quantidade: " << atualBebida->quantidade << "ml\n";: Imprime detalhes sobre a bebida, incluindo o tipo e a quantidade em mililitros.
atualBebida = atualBebida->proxima;: Move o ponteiro para a pr�xima bebida na lista.*/

/*cout << "------------------------\n";: Imprime uma linha divis�ria ap�s mostrar os detalhes do pedido.*/
    
 

    void mostrarIngredientesPastel(const string& tipo) const {
        cout << "Ingredientes do Pastel:\n";

        if (tipo == "Queijo") {
            cout << "Massa, Queijo\n";
        } else if (tipo == "Frango") {
            cout << "Massa, Frango\n";
        } else if (tipo == "Pizza") {
            cout << "Massa, Queijo, Presunto, Tomate, Or�gano\n";
        } else if (tipo == "Vento") {
            cout << "Massa\n";
        }
    }
/*cout << "Ingredientes do Pastel:\n";: Imprime uma mensagem indicando que os ingredientes do pastel ser�o listados.*/

/*if (tipo == "Queijo") { ... }: Verifica se o tipo de pastel � "Queijo". Se for verdadeiro, executa o bloco de c�digo dentro do if.
cout << "Massa, Queijo\n";: Imprime os ingredientes do pastel queijo, que consistem em massa e queijo.*/

/*else if (tipo == "Frango") { ... }: Verifica se o tipo de pastel � "Frango". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
cout << "Massa, Queijo, Presunto, Tomate, Or�gano\n";: Imprime os ingredientes do pastel pizza, que consistem em massa, queijo, presunto, tomate e or�gano.*/

/*else if (tipo == "Vento") { ... }: Verifica se o tipo de pastel � "Vento". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
cout << "Massa\n";: Imprime os ingredientes do pastel vento, que consistem apenas em massa.*/

/*Essa fun��o fornece uma descri��o dos ingredientes espec�ficos para cada tipo de pastel, com base no tipo fornecido como argumento. 
Isso permite mostrar informa��es detalhadas sobre os past�is al�m das informa��es b�sicas exibidas na fun��o mostrarDetalhesPedido.*/   
    
   


    bool verificarEstoque(const string& tipo, double quantidade) const {
        if (tipo == "Queijo" && estoque.queijo < (30.0 * quantidade)) {
            cout << "Estoque insuficiente de Queijo.\n";
            return false;
        } else if (tipo == "Presunto" && estoque.presunto < (30.0 * quantidade)) {
            cout << "Estoque insuficiente de Presunto.\n";
            return false;
        } else if (tipo == "Frango" && estoque.frango < (30.0 * quantidade)) {
            cout << "Estoque insuficiente de Frango.\n";
            return false;
        }

        return true;
    }
/*bool representa valores booleanos, ou seja, valores l�gicos que podem ser verdadeiros ou falsos*/    
    
/*if (tipo == "Queijo" && estoque.queijo < (30.0 * quantidade)) { ... }: Verifica se o tipo de ingrediente � "Queijo" e se a quantidade desejada ultrapassa o 
estoque dispon�vel. Se for verdadeiro, executa o bloco de c�digo dentro do if.
cout << "Estoque insuficiente de Queijo.\n";: Imprime uma mensagem indicando que o estoque de queijo � insuficiente.
return false;: Retorna false indicando que n�o h� estoque suficiente para atender � quantidade desejada.*/

/*else if (tipo == "Presunto" && estoque.presunto < (30.0 * quantidade)) { ... }: Verifica se o tipo de ingrediente � "Presunto" e se a quantidade desejada ultrapassa o estoque dispon�vel. Se for verdadeiro, executa o bloco de c�digo dentro do else if.
cout << "Estoque insuficiente de Presunto.\n";: Imprime uma mensagem indicando que o estoque de presunto � insuficiente.
return false;: Retorna false indicando que n�o h� estoque suficiente para atender � quantidade desejada.*/

/*else if (tipo == "Frango" && estoque.frango < (30.0 * quantidade)) { ... }: Verifica se o tipo de ingrediente � "Frango" e se a quantidade desejada ultrapassa o estoque dispon�vel. Se for verdadeiro, executa o bloco de c�digo dentro do else if.
cout << "Estoque insuficiente de Frango.\n";: Imprime uma mensagem indicando que o estoque de frango � insuficiente.
return false;: Retorna false indicando que n�o h� estoque suficiente para atender � quantidade desejada.*/

/*return true;: Se nenhuma das condi��es acima for atendida, isso significa que h� estoque suficiente para o ingrediente em quest�o, ent�o a fun��o retorna true.*/

/*Essa fun��o verifica se h� estoque suficiente para um determinado tipo de ingrediente e quantidade desejada. 
Se o estoque for insuficiente, imprime uma mensagem e retorna false; caso contr�rio, retorna true. 
Essa fun��o � �til para garantir que a barraca de past�is n�o aceite pedidos que n�o podem ser atendidos devido a limita��es de estoque.*/ 


    void atualizarEstoque(const string& tipo, double quantidade) {
        if (tipo == "Queijo") {
            estoque.queijo -= (30.0 * quantidade);
        } else if (tipo == "Presunto") {
            estoque.presunto -= (30.0 * quantidade);
        } else if (tipo == "Frango") {
            estoque.frango -= (30.0 * quantidade);
        }
    }
/*if (tipo == "Queijo") { ... }: Verifica se o tipo de ingrediente � "Queijo". Se for verdadeiro, executa o bloco de c�digo dentro do if.
estoque.queijo -= (30.0 * quantidade);: Subtrai do estoque de queijo a quantidade consumida. A quantidade � multiplicada por 30.0, 
indicando a quantidade utilizada por unidade de pastel. Isso atualiza o estoque de queijo com base na quantidade consumida.*/

/*else if (tipo == "Presunto") { ... }: Verifica se o tipo de ingrediente � "Presunto". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
estoque.presunto -= (30.0 * quantidade);: Subtrai do estoque de presunto a quantidade consumida. 
Assim como no caso do queijo, a quantidade � multiplicada por 30.0.*/

/*else if (tipo == "Frango") { ... }: Verifica se o tipo de ingrediente � "Frango". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
estoque.frango -= (30.0 * quantidade);: Subtrai do estoque de frango a quantidade consumida, multiplicada por 30.0.*/

/*essa fun��o atualiza o estoque de ingredientes espec�ficos com base na quantidade consumida. A multiplica��o por 30.0 pode ser uma conven��o de unidade, 
indicando que a quantidade � medida em unidades padr�o, e cada unidade consome 30 unidades do ingrediente em quest�o.*/

    
    

    void atualizarEstoquePedido(Pastel* primeiro) {
        Pastel* atual = primeiro;
        while (atual) {
            if (atual->tipo == "Queijo") {
                estoque.queijo -= (30.0 * atual->quantidade);
            } else if (atual->tipo == "Presunto") {
                estoque.presunto -= (30.0 * atual->quantidade);
            } else if (atual->tipo == "Frango") {
                estoque.frango -= (30.0 * atual->quantidade);
            }

            atual = atual->proximo;
        }
    }
/*Pastel* atual = primeiro;: Inicializa um ponteiro atual para apontar para o primeiro pastel na lista encadeada de past�is do pedido.*/

/*while (atual) { ... }: Inicia um loop que percorre todos os past�is no pedido at� o �ltimo pastel (o ponteiro atual n�o � nulo).
if (atual->tipo == "Queijo") { ... }: Verifica se o tipo de pastel � "Queijo". Se for verdadeiro, executa o bloco de c�digo dentro do if.
estoque.queijo -= (30.0 * atual->quantidade);: Subtrai do estoque de queijo a quantidade consumida pelo pastel. A multiplica��o por 30.0 pode indicar que cada unidade do pastel consome 30 unidades de queijo.
else if (atual->tipo == "Presunto") { ... }: Verifica se o tipo de pastel � "Presunto". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
estoque.presunto -= (30.0 * atual->quantidade);: Subtrai do estoque de presunto a quantidade consumida pelo pastel.
else if (atual->tipo == "Frango") { ... }: Verifica se o tipo de pastel � "Frango". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
estoque.frango -= (30.0 * atual->quantidade);: Subtrai do estoque de frango a quantidade consumida pelo pastel.
atual = atual->proximo;: Move o ponteiro atual para o pr�ximo pastel na lista encadeada.*/

/*Essa fun��o percorre todos os past�is em um pedido e atualiza o estoque de queijo, presunto e frango com base na quantidade consumida por cada pastel. 
Isso � �til para manter o controle preciso do estoque de ingredientes conforme os pedidos s�o atendidos.*/ 
    
    

    void atualizarContadoresVenda(Pastel* primeiro) {
        Pastel* atual = primeiro;
        while (atual) {
            if (atual->tipo == "Queijo") {
                totalPastelQueijoVendidos += atual->quantidade;
            } else if (atual->tipo == "Frango") {
                totalPastelFrangoVendidos += atual->quantidade;
            } else if (atual->tipo == "Pizza") {
                totalPastelPizzaVendidos += atual->quantidade;
            } else if (atual->tipo == "Vento") {
                totalPastelVentoVendidos += atual->quantidade;
            }

            atual = atual->proximo;
        }
    }
/*Pastel* atual = primeiro;: Inicializa um ponteiro atual para apontar para o primeiro pastel na lista encadeada de past�is.

/*while (atual) { ... }: Inicia um loop que percorre todos os past�is na lista encadeada at� o �ltimo pastel (o ponteiro atual n�o � nulo).
if (atual->tipo == "Queijo") { ... }: Verifica se o tipo de pastel � "Queijo". Se for verdadeiro, executa o bloco de c�digo dentro do if.
totalPastelQueijoVendidos += atual->quantidade;: Incrementa o contador total de past�is de queijo vendidos com a quantidade vendida do pastel atual.
else if (atual->tipo == "Frango") { ... }: Verifica se o tipo de pastel � "Frango". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
totalPastelFrangoVendidos += atual->quantidade;: Incrementa o contador total de past�is de frango vendidos com a quantidade vendida do pastel atual.
else if (atual->tipo == "Pizza") { ... }: Verifica se o tipo de pastel � "Pizza". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
totalPastelPizzaVendidos += atual->quantidade;: Incrementa o contador total de past�is de pizza vendidos com a quantidade vendida do pastel atual.
else if (atual->tipo == "Vento") { ... }: Verifica se o tipo de pastel � "Vento". Se for verdadeiro, executa o bloco de c�digo dentro do else if.
totalPastelVentoVendidos += atual->quantidade;: Incrementa o contador total de past�is de vento vendidos com a quantidade vendida do pastel atual.
atual = atual->proximo;: Move o ponteiro atual para o pr�ximo pastel na lista encadeada.*/

/*Em resumo, essa fun��o percorre todos os past�is em um pedido e atualiza os contadores de vendas para cada tipo de pastel com base na quantidade vendida. 
Isso � �til para manter o controle dos tipos de past�is mais populares e auxiliar nas an�lises de desempenho de vendas.*/
 
    

    void editarBebida(Bebida* primeira) {
        Bebida* atual = primeira;
        while (atual) {
            cout << "Bebida: " << atual->tipo << ", Quantidade: " << atual->quantidade << "ml\n";
            cout << "Deseja editar esta bebida? (1 - Sim, 0 - N�o): ";
            int opcao;
            cin >> opcao;

            if (opcao == 1) {
                cout << "Novo tipo de Bebida: ";
                cin >> atual->tipo;

                cout << "Nova quantidade da Bebida (em ml): ";
                cin >> atual->quantidade;

                cout << "Bebida editada com sucesso.\n";
                return;
            }

            atual = atual->proxima;
        }
    }
/*Bebida* atual = primeira;: Inicializa um ponteiro atual para apontar para a primeira bebida na lista encadeada.*/

/*while (atual) { ... }: Inicia um loop que percorre todas as bebidas na lista encadeada at� a �ltima bebida (o ponteiro atual n�o � nulo).
cout << "Bebida: " << atual->tipo << ", Quantidade: " << atual->quantidade << "ml\n";: Exibe informa��es sobre a bebida atual.
cout << "Deseja editar esta bebida? (1 - Sim, 0 - N�o): ";: Pergunta ao usu�rio se deseja editar a bebida atual.
int opcao; cin >> opcao;: L� a op��o do usu�rio para determinar se deseja ou n�o editar a bebida.
if (opcao == 1) { ... }: Verifica se o usu�rio escolheu editar a bebida. Se verdadeiro, executa o bloco de c�digo dentro do if.
cout << "Novo tipo de Bebida: "; cin >> atual->tipo;: Solicita e l� o novo tipo de bebida.
cout << "Nova quantidade da Bebida (em ml): "; cin >> atual->quantidade;: Solicita e l� a nova quantidade da bebida em mililitros.
cout << "Bebida editada com sucesso.\n";: Exibe uma mensagem informando que a bebida foi editada com sucesso.
return;: Encerra a fun��o, uma vez que a bebida foi editada.
atual = atual->proxima;: Move o ponteiro atual para a pr�xima bebida na lista encadeada.*/

/*Essa fun��o oferece uma intera��o amig�vel para editar as caracter�sticas de uma bebida em um pedido, 
dando ao usu�rio a op��o de modificar o tipo e a quantidade da bebida escolhida.*/     
};



void gerarRelatorioVendas(const BarracaPastel& barraca, Pedido* primeiroPedido, const EstoqueMateriasPrimas& estoque) {
    const string nomeArquivo = "relatorio_vendas.txt";
    ofstream arquivo(nomeArquivo.c_str());

    if (!arquivo.is_open()) {
        cerr << "Erro ao abrir o arquivo de relat�rio.\n";
        return;
    }

    arquivo << "BEBIDAS\n========\n";
    int cocaColaVendidas = 0;
    int pepsiVendidas = 0;

    Pedido* atualPedido = primeiroPedido;
    while (atualPedido) {
        Bebida* atualBebida = atualPedido->primeiraBebida;

        while (atualBebida) {
            if (atualBebida->tipo == "Coca-Cola") {
                cocaColaVendidas++;
            } else if (atualBebida->tipo == "Pepsi") {
                pepsiVendidas++;
            }

            atualBebida = atualBebida->proxima;
        }

        atualPedido = atualPedido->proximo;
    }

    arquivo << "Coca-Cola " << cocaColaVendidas << " vendidas\n";
    arquivo << "Pepsi " << pepsiVendidas << " vendidas\n";

    arquivo << "\n\nPASTEL\n======\n";
int pastelFrangoPedidos = 0;
int pastelQueijoPedidos = 0;
int pastelPizzaPedidos = 0;
int pastelVentoPedidos = 0; // Adicione esta linha

atualPedido = primeiroPedido;
while (atualPedido) {
    if (atualPedido->entregue) {
        Pastel* atualPastel = atualPedido->primeiroPastel;

        while (atualPastel) {
            if (atualPastel->tipo == "Frango") {
                pastelFrangoPedidos++;
            } else if (atualPastel->tipo == "Queijo") {
                pastelQueijoPedidos++;
            } else if (atualPastel->tipo == "Pizza") {
                pastelPizzaPedidos++;
            } else if (atualPastel->tipo == "Vento") { // Adicione esta linha
                pastelVentoPedidos++;                  // Adicione esta linha
            }

            atualPastel = atualPastel->proximo;
        }
    }

    atualPedido = atualPedido->proximo;
}

arquivo << "Pastel de Frango: " << pastelFrangoPedidos << " pedidos entregues\n";
arquivo << "Pastel de Queijo: " << pastelQueijoPedidos << " pedidos entregues\n";
arquivo << "Pastel de Pizza: " << pastelPizzaPedidos << " pedidos entregues\n";
arquivo << "Pastel de Vento: " << pastelVentoPedidos << " pedidos entregues\n";  // Adicione esta linha


    arquivo << "\n\nESTOQUE RESTANTE\n=================\n";
    arquivo << "Queijo restante: " << estoque.queijo << " gramas\n";
    arquivo << "Presunto restante: " << estoque.presunto << " gramas\n";
    arquivo << "Frango restante: " << estoque.frango << " gramas\n";

    arquivo.close();

    cout << "Relat�rio de vendas gerado com sucesso. Consulte o arquivo: " << nomeArquivo << "\n";
}
/*const string nomeArquivo = "relatorio_vendas.txt";: Define o nome do arquivo onde o relat�rio ser� salvo.*/

/*ofstream arquivo(nomeArquivo.c_str());: Abre um arquivo de sa�da (ofstream) para escrita e associa o arquivo ao nome especificado.*/

/*if (!arquivo.is_open()) { ... }: Verifica se a abertura do arquivo foi bem-sucedida. Se n�o for, exibe uma mensagem de erro e encerra a fun��o.*/

/*arquivo << "BEBIDAS\n========\n";: Escreve no arquivo a se��o de bebidas do relat�rio.*/

/*int cocaColaVendidas = 0; int pepsiVendidas = 0;: Inicializa contadores para o n�mero de Coca-Colas e Pepsis vendidas.*/

/*Pedido* atualPedido = primeiroPedido;: Inicializa um ponteiro para percorrer a lista de pedidos.*/

/*while (atualPedido) { ... }: Inicia um loop que percorre todos os pedidos.
Bebida* atualBebida = atualPedido->primeiraBebida;: Inicializa um ponteiro para percorrer a lista de bebidas dentro do pedido atual.
while (atualBebida) { ... }: Loop interno que percorre todas as bebidas dentro do pedido atual.
Verifica o tipo de bebida (Coca-Cola ou Pepsi) e incrementa os contadores apropriados.
atualBebida = atualBebida->proxima;: Move o ponteiro para a pr�xima bebida na lista encadeada.
atualPedido = atualPedido->proximo;: Move o ponteiro para o pr�ximo pedido na lista encadeada.*/



/*arquivo << "Coca-Cola " << cocaColaVendidas << " vendidas\n";
arquivo << "Pepsi " << pepsiVendidas << " vendidas\n";
Escrevem no arquivo o n�mero de Coca-Colas e Pepsis vendidas.*/



/*int pastelFrangoPedidos = 0;
int pastelQueijoPedidos = 0;
int pastelPizzaPedidos = 0;
int pastelVentoPedidos = 0; // Adicione esta linha

atualPedido = primeiroPedido;
while (atualPedido) {
    if (atualPedido->entregue) {
        Pastel* atualPastel = atualPedido->primeiroPastel;

        while (atualPastel) {
            if (atualPastel->tipo == "Frango") {
                pastelFrangoPedidos++;
            } else if (atualPastel->tipo == "Queijo") {
                pastelQueijoPedidos++;
            } else if (atualPastel->tipo == "Pizza") {
                pastelPizzaPedidos++;
            } else if (atualPastel->tipo == "Vento") { // Adicione esta linha
                pastelVentoPedidos++;                  // Adicione esta linha
            }

            atualPastel = atualPastel->proximo;
        }
    }

    atualPedido = atualPedido->proximo;
}
Repete o processo para a se��o de past�is, contando o n�mero de pedidos entregues para cada tipo de pastel.*/



/*Escreve no arquivo o n�mero de pedidos entregues para cada tipo de pastel.
arquivo << "Pastel de Frango: " << pastelFrangoPedidos << " pedidos entregues\n";
arquivo << "Pastel de Queijo: " << pastelQueijoPedidos << " pedidos entregues\n";
arquivo << "Pastel de Pizza: " << pastelPizzaPedidos << " pedidos entregues\n";
arquivo << "Pastel de Vento: " << pastelVentoPedidos << " pedidos entregues\n";*/


/*arquivo << "\n\nESTOQUE RESTANTE\n=================\n";: Adiciona uma se��o para o estoque restante no arquivo.*/


/*Escreve no arquivo a quantidade restante de queijo, presunto e frango no estoque.
arquivo << "Queijo restante: " << estoque.queijo << " gramas\n";
arquivo << "Presunto restante: " << estoque.presunto << " gramas\n";
arquivo << "Frango restante: " << estoque.frango << " gramas\n";*/

/*arquivo.close();: Fecha o arquivo ap�s a escrita.*/


/*Exibe uma mensagem indicando o sucesso na gera��o do relat�rio e o nome do arquivo criado.
 cout << "Relat�rio de vendas gerado com sucesso. Consulte o arquivo: " << nomeArquivo << "\n";*/
 
/*Essa fun��o, portanto, gera um relat�rio de vendas e estoque com base nos pedidos realizados, 
contando o n�mero de bebidas vendidas e a quantidade restante de ingredientes no estoque.*/



void mostrarMenu(BarracaPastel& barraca) {
    int opcao;

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Cadastrar Pedido\n";
        cout << "2. Listar Pedidos\n";
        cout << "3. Marcar pedido como enregue \n";
        cout << "4. Editar Pedido\n";
        cout << "5. Gerar Relat�rio de Vendas\n";
        cout << "6. Sair\n";
        cout << "7. Excluir pedido\n ";
        

        cout << "Escolha uma op��o: ";
        cin >> opcao;

        switch (opcao) {
            case 1:
                barraca.cadastrarPedido();
                break;
            case 2:
                barraca.listarPedidos();
                break;
            case 3:
                int senhaEntregue;
                cout << "Digite a senha do pedido a ser marcado como entregue: ";
                cin >> senhaEntregue;
                barraca.marcarPedidoComoEntregue(senhaEntregue);
                break;
            case 4:
                int senhaEditar;
                cout << "Digite a senha do pedido a ser editado: ";
                cin >> senhaEditar;
                barraca.editarPedido(senhaEditar);
                break;
            case 5:
                gerarRelatorioVendas(barraca, barraca.getPrimeiroPedido(), barraca.getEstoque());
                break;
            case 6:
                cout << "Saindo do programa. At� logo!\n";
                return;
            default:
                cout << "Op��o inv�lida. Tente novamente.\n";
            case 7:
                int senhaExcluir;
                cout << "Digite a senha do pedido a ser exclu�do: ";
                cin >> senhaExcluir;
                barraca.excluirPedido(senhaExcluir);
                break;
        }
    }
}
/*Essa fun��o mostrarMenu representa o menu principal de intera��o com a barraca de past�is.*/

/*int opcao;: Declara��o da vari�vel opcao para armazenar a escolha do usu�rio.*/

/*while (true) { ... }: Um loop que continuar� executando indefinidamente at� que a op��o 6 (sair) seja escolhida.
cout << "\nMenu:\n"; ...: Exibe as op��es do menu para o usu�rio.
cout << "Escolha uma op��o: "; cin >> opcao;: Solicita ao usu�rio que escolha uma op��o e armazena a escolha na vari�vel opcao.
switch (opcao) { ... }: Inicia uma estrutura de controle switch para lidar com diferentes op��es do menu.
case 1:: Se a op��o escolhida for 1, cadastra um novo pedido utilizando o m�todo cadastrarPedido da barraca.
case 2:: Se a op��o escolhida for 2, lista todos os pedidos utilizando o m�todo listarPedidos da barraca.
case 3:: Se a op��o escolhida for 3, solicita a senha do pedido a ser marcado como entregue e chama o m�todo marcarPedidoComoEntregue da barraca.
case 4:: Se a op��o escolhida for 4, solicita a senha do pedido a ser editado e chama o m�todo editarPedido da barraca.
case 5:: Se a op��o escolhida for 5, chama a fun��o gerarRelatorioVendas com os par�metros adequados.
case 6:: Se a op��o escolhida for 6, exibe uma mensagem de sa�da e retorna, encerrando o programa.
case 7:: Se a op��o escolhida for 7, solicita a senha do pedido a ser exclu�do e chama o m�todo excluirPedido da barraca.
default:: Se a op��o n�o corresponder a nenhum dos cases anteriores, exibe uma mensagem de op��o inv�lida.*/

/*No final do loop, a execu��o volta ao in�cio, aguardando uma nova escolha do usu�rio.*/


int main() {
	setlocale(LC_ALL, "Portuguese");
    BarracaPastel barraca;
    mostrarMenu(barraca);

    // Pass the necessary parameters to the function
    gerarRelatorioVendas(barraca, barraca.getPrimeiroPedido(), barraca.getEstoque());

    return 0;
}
/*int: Indica que a fun��o main retorna um valor inteiro.
main(): Nome da fun��o principal do programa.
{}: O bloco de c�digo entre chaves cont�m as instru��es que ser�o executadas quando o programa iniciar.
O valor retornado (return 0;) indica o status de sa�da do programa. Um valor de retorno 0 geralmente indica que o programa foi executado com sucesso. 
Outros valores podem indicar diferentes tipos de erros ou estados.*/

/*setlocale(LC_ALL, "Portuguese");: Define a localidade para "Portuguese". Essa fun��o � usada para definir a localidade, 
que afeta a formata��o de sa�da de dados, como datas e n�meros, para se adequar �s conven��es culturais do idioma.*/

/*BarracaPastel barraca;: Cria uma inst�ncia da classe BarracaPastel, que representa a barraca de past�is.*/

/*mostrarMenu(barraca);: Chama a fun��o mostrarMenu, passando a inst�ncia da barraca como argumento. 
Esta fun��o permite que o usu�rio interaja com a barraca atrav�s de um menu.*/

/*gerarRelatorioVendas(barraca, barraca.getPrimeiroPedido(), barraca.getEstoque());: Chama a fun��o gerarRelatorioVendas para gerar um relat�rio de vendas. 
Esta fun��o aceita a inst�ncia da barraca, o primeiro pedido e o estoque como par�metros.*/

/*return 0;: Indica que o programa foi executado com sucesso e retorna 0, indicando que n�o houve erros durante a execu��o.*/

/*O programa cria uma barraca de past�is, permite que o usu�rio interaja com a barraca atrav�s de um menu, e ao final gera um relat�rio de vendas. 
A utiliza��o de classes e fun��es ajuda a organizar e estruturar o c�digo de forma modular e mais f�cil de entender.*/
