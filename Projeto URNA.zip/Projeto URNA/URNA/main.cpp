#include <iostream>
#include <fstream>
#include <string>
#include <locale>

using namespace std;

// Estrutura para armazenar informa��es sobre candidatos
struct Candidato {
    string nome;
    int numero;
    int votos;
    Candidato* proximo;
};

Candidato* listaCandidatos = NULL;

// Estrutura para armazenar informa��es sobre votos
struct Voto {
    int tituloEleitor;
    int numeroCandidato;
    Voto* proximo;
};

Voto* listaVotos = NULL;


// Declara��o das fun��es relacionadas aos candidatos
void salvarCandidatos();
void carregarCandidatos();

// Fun��o para inserir um novo candidato na lista
void inserirCandidato(const string& nome, int numero) {
    Candidato* novoCandidato = new Candidato{nome, numero, NULL};
    novoCandidato->proximo = listaCandidatos;
    listaCandidatos = novoCandidato;
}

// Fun��o para remover um candidato da lista
void removerCandidato(int numero) {
    Candidato* atual = listaCandidatos;
    Candidato* anterior = NULL;

    while (atual != NULL && atual->numero != numero) {
        anterior = atual;
        atual = atual->proximo;
    }

    if (atual != NULL) {
        if (anterior != NULL) {
            anterior->proximo = atual->proximo;
        } else {
            listaCandidatos = atual->proximo;
        }

        delete atual;
    }
}

// Fun��o para listar os candidatos
void listarCandidatos() {
    Candidato* atual = listaCandidatos;

    while (atual != NULL) {
        cout << "Nome: " << atual->nome << ", N�mero: " << atual->numero << endl;
        atual = atual->proximo;
    }
}

// Fun��o para mudar o n�mero de um candidato
void mudarNumeroCandidato(int numeroAntigo, int novoNumero) {
    Candidato* atual = listaCandidatos;

    while (atual != NULL) {
        if (atual->numero == numeroAntigo) {
            atual->numero = novoNumero;
            cout << "N�mero do candidato alterado com sucesso!" << endl;
            return;
        }
        atual = atual->proximo;
    }

    cout << "Candidato n�o encontrado." << endl;
}

void salvarCandidatos() {
    ofstream arquivo("candidatos.txt");

    Candidato* atual = listaCandidatos;
    while (atual != NULL) {
        arquivo << atual->nome << " " << atual->numero << endl;
        atual = atual->proximo;
    }

    arquivo.close();
}

void carregarCandidatos() {
    ifstream arquivo("candidatos.txt");

    string nome;
    int numero;

    while (arquivo >> nome >> numero) {
        inserirCandidato(nome, numero);
    }

    arquivo.close();
}


void registrarVotoCandidato(int numeroCandidato) {
    Candidato* atualCandidato = listaCandidatos;
    while (atualCandidato != NULL) {
        if (atualCandidato->numero == numeroCandidato) {
            atualCandidato->votos++;
            break;
        }
        atualCandidato = atualCandidato->proximo;
    }
}


void criarArquivoVotosCandidatos() {
    ofstream arquivo("votos_candidatos.txt");

    Candidato* atualCandidato = listaCandidatos;
    while (atualCandidato != NULL) {
        arquivo << "N�mero: " << atualCandidato->numero << ", Nome: " << atualCandidato->nome << ", Votos: " << atualCandidato->votos << endl;
        atualCandidato = atualCandidato->proximo;
    }

    arquivo.close();
}



// Estrutura para armazenar informa��es sobre eleitores
struct Eleitor {
    string nome;
    int titulo;
    bool votou;
    bool apto;
    bool naoVotouUltimaEleicao;  // Novo campo
    Eleitor* proximo;
};


void listarEleitoresNaoVotaram();

Eleitor* listaEleitores = NULL;


// Fun��o para inserir um novo eleitor na lista
void inserirEleitor(const string& nome, int titulo) {
    // Verifique se o eleitor j� est� na lista (por t�tulo de eleitor)
    Eleitor* atual = listaEleitores;
    while (atual != NULL) {
        if (atual->titulo == titulo) {
            // Eleitor j� existe, n�o � necess�rio criar um novo
            return;
        }
        atual = atual->proximo;
    }

    // Eleitor n�o encontrado, cria um novo
    Eleitor* novoEleitor = new Eleitor{nome, titulo, false, false, true, NULL};

    // Adiciona o eleitor � lista
    novoEleitor->proximo = listaEleitores;
    listaEleitores = novoEleitor;
}



// Fun��o para registrar que um eleitor votou
void registrarVoto(int tituloEleitor, int numeroCandidato) {
    Eleitor* atualEleitor = listaEleitores;
    while (atualEleitor != NULL) {
        if (atualEleitor->titulo == tituloEleitor) {
            atualEleitor->votou = true;
            break;
        }
        atualEleitor = atualEleitor->proximo;
    }

    Voto* novoVoto = new Voto{tituloEleitor, numeroCandidato, NULL};
    novoVoto->proximo = listaVotos;
    listaVotos = novoVoto;
}



bool eleitorAptoVotar(int titulo);



void votar(int tituloEleitor) {
    Eleitor* atualEleitor = listaEleitores;
    
    // Procura o eleitor na lista
    while (atualEleitor != NULL) {
        if (atualEleitor->titulo == tituloEleitor) {
            // Verifica se o eleitor j� votou
            if (atualEleitor->votou) {
                cout << "Voc� j� votou. N�o � permitido votar mais de uma vez." << endl;
                return;  // Encerra a fun��o sem permitir novo voto
            }

            // Mostra os candidatos dispon�veis para vota��o
            cout << "Lista de Candidatos Dispon�veis:" << endl;
            listarCandidatos();
            
            // Solicita o n�mero do candidato escolhido
            cout << "Digite o n�mero do candidato escolhido (ou 0 para voto em branco, -1 para voto nulo): ";
            int numeroCandidato;
            cin >> numeroCandidato;

            // Registra o voto conforme a escolha do eleitor
            if (numeroCandidato == 0) {
                registrarVoto(tituloEleitor, 0); // Voto em branco
                cout << "Voto em branco registrado com sucesso!" << endl;
            } else if (numeroCandidato == -1) {
                registrarVoto(tituloEleitor, -1); // Voto nulo
                cout << "Voto nulo registrado com sucesso!" << endl;
            } else if (numeroCandidato > 0) {
                registrarVoto(tituloEleitor, numeroCandidato);
                registrarVotoCandidato(numeroCandidato);  // Registrar voto para o candidato
                cout << "Voto registrado com sucesso!" << endl;
            } else {
                cout << "Op��o inv�lida." << endl;
            }

            // Marca o eleitor como votou
            atualEleitor->votou = true;
            
            return;  // Encerra a fun��o ap�s o voto
        }

        atualEleitor = atualEleitor->proximo;
    }

    // Se o eleitor n�o foi encontrado, exibe uma mensagem de erro
    cout << "Eleitor n�o encontrado." << endl;
}




// Fun��o para gerar relat�rio de eleitores
void gerarRelatorioEleitores() {
    int totalEleitores = 0;
    int eleitoresAptos = 0;
    int eleitoresNaoAptos = 0;
    int votosBranco = 0;
    int votosNulo = 0;

    Eleitor* atualEleitor = listaEleitores;
    while (atualEleitor != NULL) {
        totalEleitores++;
        if (atualEleitor->apto) {
            eleitoresAptos++;
        } else {
            eleitoresNaoAptos++;
        }
        atualEleitor = atualEleitor->proximo;
    }

    Voto* atualVoto = listaVotos;
    while (atualVoto != NULL) {
        if (atualVoto->numeroCandidato == 0) {
            votosBranco++;
        } else if (atualVoto->numeroCandidato == -1) {
            votosNulo++;
        }
        atualVoto = atualVoto->proximo;
    }

    ofstream relatorio("relatorio_eleitores.txt");
    relatorio << "Total de eleitores: " << totalEleitores << endl;
    relatorio << "Votos em branco: " << votosBranco << endl;
    relatorio << "Votos nulos: " << votosNulo << endl;
    relatorio.close();
}



void gerarArquivoEleitoresVotaram() {
    ofstream arquivo("eleitores_votaram.txt");

    Eleitor* atualEleitor = listaEleitores;
    int eleitoresVotaram = 0;

    while (atualEleitor != NULL) {
        if (atualEleitor->votou) {
            eleitoresVotaram++;
        }
        atualEleitor = atualEleitor->proximo;
    }

    arquivo << "Quantidade de eleitores que votaram: " << eleitoresVotaram << endl;

    arquivo.close();
}


void gerarArquivoEleitoresNaoVotaram() {
    ofstream arquivo("eleitores_nao_votaram.txt");

    Eleitor* atualEleitor = listaEleitores;
    int eleitoresNaoVotaram = 0;

    while (atualEleitor != NULL) {
        if (!atualEleitor->votou) {
            eleitoresNaoVotaram++;
        }
        atualEleitor = atualEleitor->proximo;
    }

    arquivo << "Quantidade de eleitores que n�o votaram: " << eleitoresNaoVotaram << endl;

    arquivo.close();
}




void removerEleitor(int titulo) {
    Eleitor* atual = listaEleitores;
    Eleitor* anterior = NULL;

    while (atual != NULL && atual->titulo != titulo) {
        anterior = atual;
        atual = atual->proximo;
    }

    if (atual != NULL) {
        if (anterior != NULL) {
            anterior->proximo = atual->proximo;
        } else {
            listaEleitores = atual->proximo;
        }

        delete atual;
    }
}



// Fun��o para salvar a lista de eleitores em um arquivo
void salvarEleitores() {
    ofstream arquivo("eleitores.txt");

    Eleitor* atual = listaEleitores;
    while (atual != NULL) {
        arquivo << atual->nome << " " << atual->titulo << " " << atual->votou << " " << atual->apto << endl;
        atual = atual->proximo;
    }

    arquivo.close();
}



// Fun��o para carregar a lista de eleitores de um arquivo
void carregarEleitores() {
    ifstream arquivo("eleitores.txt");

    string nome;
    int titulo;
    bool votou;
    bool apto;

    while (arquivo >> nome >> titulo >> votou >> apto) {
    inserirEleitor(nome, titulo);
    Eleitor* atual = listaEleitores;
    while (atual->titulo != titulo) {
        atual = atual->proximo;
    }
    atual->votou = votou;
    atual->apto = apto;
    // Ajuste para definir corretamente naoVotouUltimaEleicao
    atual->naoVotouUltimaEleicao = !votou;
}

    arquivo.close();
}



// Fun��o para salvar a lista de votos em um arquivo
void salvarVotos() {
    ofstream arquivo("votos.txt");

    Voto* atual = listaVotos;
    while (atual != NULL) {
        arquivo << atual->tituloEleitor << " " << atual->numeroCandidato << endl;
        atual = atual->proximo;
    }

    arquivo.close();
}



// Fun��o para carregar a lista de votos de um arquivo
void carregarVotos() {
    ifstream arquivo("votos.txt");

    int tituloEleitor, numeroCandidato;

    while (arquivo >> tituloEleitor >> numeroCandidato) {
        registrarVoto(tituloEleitor, numeroCandidato);
    }

    arquivo.close();
}



void listarEleitores() {
    Eleitor* atual = listaEleitores;

    while (atual != NULL) {
        cout << "Nome: " << atual->nome << ", T�tulo Eleitoral: " << atual->titulo;
        if (atual->votou) {
            cout << " - J� votou";
        } else {
            cout << " - N�o votou ainda";
        }
        cout << endl;

        atual = atual->proximo;
    }
}




void listarEleitoresNaoVotaram() {
    Eleitor* atual = listaEleitores;

    cout << "Eleitores que n�o votaram:" << endl;
    while (atual != NULL) {
        if (!atual->votou && atual->naoVotouUltimaEleicao) {
            cout << "Nome: " << atual->nome << ", T�tulo Eleitoral: " << atual->titulo << endl;
        }
        atual = atual->proximo;
    }
}



void perguntarVotar(int tituloEleitor) {
    char resposta;
    cout << "Deseja votar? (S para Sim, N para N�o): ";
    cin >> resposta;

    Eleitor* atualEleitor = listaEleitores;

    while (atualEleitor != NULL) {
        if (atualEleitor->titulo == tituloEleitor) {
            if (toupper(resposta) == 'S') {
                votar(tituloEleitor);
            } else {
                // Ajuste para definir corretamente naoVotouUltimaEleicao
                atualEleitor->naoVotouUltimaEleicao = true;

                // Se o eleitor escolhe n�o votar, exibe uma mensagem e encerra a fun��o
                cout << "Eleitor optou por n�o votar." << endl;
            }
            return;
        }

        atualEleitor = atualEleitor->proximo;
    }

    // Se o eleitor n�o foi encontrado, exibe uma mensagem de erro
    cout << "Eleitor n�o encontrado." << endl;
}



bool eleitorAptoVotar(int titulo) {
    Eleitor* atual = listaEleitores;

    while (atual != NULL) {
        if (atual->titulo == titulo) {
            return atual->apto && !atual->votou;
        }
        atual = atual->proximo;
    }

    return false;
}



// Fun��o principal
int main() {
	setlocale(LC_ALL, "Portuguese");
    int opcao;

    do {
        cout << "===== Menu de Op��es =====" << endl;
        cout << "1. Inserir Candidato" << endl;
        cout << "2. Remover Candidato" << endl;
        cout << "3. Listar Candidatos" << endl;
        cout << "4. Mudar N�mero do Candidato" << endl;
        cout << "5. Inserir Eleitor" << endl;
        cout << "6. Salvar Dados" << endl;
        cout << "7. Carregar Dados" << endl;
        cout << "8. Gerar Relat�rio de Eleitores nulos, brancos e o total de eleitores" << endl;
        cout << "9. Remover Eleitor" << endl;
        cout << "10. Listar eleitores" << endl;
        cout << "11. Votar" << endl;  // Adicionada nova op��o
        cout << "12. Gerar arquivo de votos dos candidatos" << endl;
        cout << "13. Gerar Relat�rio de Eleitores que votaram" << endl;
        cout << "14. Gerar Relat�rio de Eleitores que n�o votaram" << endl;
        cout << "0. Sair" << endl;
        cout << "Escolha uma op��o: ";
        cin >> opcao;

        switch (opcao) {
            case 1: {
                string nome;
                int numero;
                cout << "Digite o nome do candidato: ";
                cin >> nome;
                cout << "Digite o n�mero do candidato: ";
                cin >> numero;
                inserirCandidato(nome, numero);
                break;
            }
            case 2: {
                int numero;
                cout << "Digite o n�mero do candidato a ser removido: ";
                cin >> numero;
                removerCandidato(numero);
                break;
            }
            case 3:
                listarCandidatos();
                break;
            case 4: {
                int numeroAntigo, novoNumero;
                cout << "Digite o n�mero do candidato a ser alterado: ";
                cin >> numeroAntigo;
                cout << "Digite o novo n�mero do candidato: ";
                cin >> novoNumero;
                mudarNumeroCandidato(numeroAntigo, novoNumero);
                break;
            }
            case 5: {
                string nome;
                int titulo;
                cout << "Digite o nome do eleitor: ";
                cin >> nome;
                cout << "Digite o t�tulo do eleitor: ";
                cin >> titulo;
                inserirEleitor(nome, titulo);
                break;
            }
           
            case 6:
                salvarEleitores();
                salvarCandidatos();
                salvarVotos();
                cout << "Dados salvos com sucesso!" << endl;
                break;
            case 7:
                carregarEleitores();
                carregarCandidatos();
                carregarVotos();
                cout << "Dados carregados com sucesso!" << endl;
                break;
            case 8:
                gerarRelatorioEleitores();
                cout << "Relat�rio de eleitores nulos, brancos e o total de eleitores gerado com sucesso!" << endl;
                break;
            case 9: {
                int titulo;
                cout << "Digite o t�tulo do eleitor a ser removido: ";
                cin >> titulo;
                removerEleitor(titulo);
                break;
            }
             case 10: {  // Novo caso para listar eleitores
                listarEleitores();
                break;
            }
               case 11: {
                // Novo caso para perguntar se o eleitor deseja votar
                int tituloEleitor;
                cout << "Digite o t�tulo do eleitor: ";
                cin >> tituloEleitor;
                perguntarVotar(tituloEleitor);
                break;
            }
            case 12:
                criarArquivoVotosCandidatos();  // Criar arquivo com votos de cada candidato
                break;
            case 13:
            gerarArquivoEleitoresVotaram();
            cout << "Relat�rio de eleitores que votaram gerado com sucesso!" << endl;
            break;
            
			case 14:
            gerarArquivoEleitoresNaoVotaram();
            cout << "Relat�rio de eleitores que n�o votaram gerado com sucesso!" << endl;
            break;
            
            
			case 0:
                break;
            default:
                cout << "Op��o inv�lida. Tente novamente." << endl;
        }

    } while (opcao != 0);

    return 0;
}
