#include <iostream>
#include <string>
#include <stdlib.h>
#include <locale>

using namespace std;

string recebe_nome_professor();
string recebe_disciplina_professor();
string recebe_email_professor();
string recebe_titulacao_professor();


int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");
    struct cadastro {
        string nome;
        string disciplina;
        string email;
        string titulacao;
        int data_nasc;
    };

    int TOTAL = 5;
    int x;
    struct cadastro vetor_professor[TOTAL];

    for ( x = 0; x<TOTAL; x++) {
        vetor_professor[x].nome = recebe_nome_professor();
        vetor_professor[x].disciplina = recebe_disciplina_professor();
        vetor_professor[x].email = recebe_email_professor();
        vetor_professor[x].titulacao = recebe_titulacao_professor();

}

    for ( x = 0; x<TOTAL; x++) {
    	cout << endl;
        cout << "Nome do professor = " << vetor_professor[x].nome << endl;
        cout << "Disciplina do professor = " << vetor_professor[x].disciplina << endl;
        cout << "Email do professor = " << vetor_professor[x].email << endl;
        cout << "Titula��o do professor = " << vetor_professor[x].titulacao << endl;
    }
    cout<<endl;

    return 0;
}

string recebe_nome_professor() {
    string nome_recebido;
    cout << "Digite o nome do professor: ";
    cin >> nome_recebido;
    return nome_recebido;
    cout << endl;
}

string recebe_disciplina_professor() {
    string disciplina;
    cout << "Digite a disciplina que o professor ir� lecionar: ";
    cin >> disciplina;
    return disciplina;
    cout << endl;
}

string recebe_email_professor() {
    string email;
    cout << "Digite o email do professor: ";
    cin >> email;
    return email;
    cout << endl;
}

string recebe_titulacao_professor() {
    string titulacao;
    cout << "Digite a titula��o do professor: ";
    cin >> titulacao;
    return titulacao;
    cout << endl;
}
