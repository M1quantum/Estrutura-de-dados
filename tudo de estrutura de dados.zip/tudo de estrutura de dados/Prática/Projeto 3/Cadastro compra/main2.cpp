#include <iostream>
#include <string>
#include <stdlib.h>
#include <locale>

using namespace std;

string recebe_nome_cliente();
string recebe_sobrenome_cliente();
string recebe_cpf_cliente();
string recebe_nomeproduto_cliente();
string recebe_marcaproduto_cliente();
float recebe_valorproduto_cliente();
int recebe_parcelas_cliente();
int recebe_numerocartao_cliente();








int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");
    struct cadastro {
        string nome;
        string sobrenome;
        string cpf;
        string nomeproduto;
        string marcaproduto;
        float valorproduto;
        int parcelas;
        float valorparcelas;
        int numerocartao;
    };
    
    int TOTAL = 2;
    int x;
    struct cadastro vetor_cliente[TOTAL];
    
    for(x = 0; x<TOTAL; x++){
    vetor_cliente[x].nome = recebe_nome_cliente();
    vetor_cliente[x].sobrenome = recebe_sobrenome_cliente();
    vetor_cliente[x].cpf = recebe_cpf_cliente();
    vetor_cliente[x].nomeproduto = recebe_nomeproduto_cliente();
    vetor_cliente[x].marcaproduto = recebe_marcaproduto_cliente();
    vetor_cliente[x].valorproduto = recebe_valorproduto_cliente();
    vetor_cliente[x].parcelas = recebe_parcelas_cliente();
    vetor_cliente[x].numerocartao = recebe_numerocartao_cliente();
    
    cout << endl;
}
    for ( x = 0; x<TOTAL; x++) {
    if(vetor_cliente[x].parcelas <= 12){
    
    cout << "Quantidade de parcelas que vai dividir = " << vetor_cliente[x].parcelas << endl;
    cout << "Nome = " << vetor_cliente[x].nome << endl;
    cout << "Sobrenome = " << vetor_cliente[x].sobrenome << endl;
    cout << "Cpf = " << vetor_cliente[x].cpf << endl;
    cout << "Produto = " << vetor_cliente[x].nomeproduto << endl;
    cout << "Marca do produto = " << vetor_cliente[x].marcaproduto << endl; 
	cout << "N�mero do cart�o = " << vetor_cliente[x].numerocartao << endl;   
    cout << "Valor do produto = " << vetor_cliente[x].valorproduto << endl;  
    vetor_cliente[x].valorparcelas = (vetor_cliente[x].valorproduto / vetor_cliente[x].parcelas);
    cout << "Valor de cada parcela = " << vetor_cliente[x].valorparcelas << endl;
}else{
	cout << "N�o � permitido parcelar acima de doze vezes. A compra do produto " << vetor_cliente[x].nomeproduto << " foi cancelada \n";
  }
  cout << endl;
}
	
    
    
    
    
    
    return 0;
}


string recebe_nome_cliente(){
    string nome_recebido;
    cout << "Digite o nome do cliente: ";
    cin >> nome_recebido;
    return nome_recebido;
}

string recebe_sobrenome_cliente(){
    string sobrenome_recebido;
    cout << "Digite o sobrenome do cliente: ";
    cin >> sobrenome_recebido;
    return sobrenome_recebido;

}

string recebe_cpf_cliente(){
    string cpf_recebido;
    cout << "Digite o CPF do cliente: ";
    cin >> cpf_recebido;
    return cpf_recebido;

}

string recebe_nomeproduto_cliente(){
    string nomeproduto_recebido;
    cout << "Digite o produto a ser comprado: ";
    cin >> nomeproduto_recebido;
    return nomeproduto_recebido;

}

string recebe_marcaproduto_cliente(){
    string marcaproduto_recebido;
    cout << "Digite a marca do produto a ser comprado: ";
    cin >> marcaproduto_recebido;
    return marcaproduto_recebido;

}

float recebe_valorproduto_cliente() {
    float valorproduto_recebido;
    cout << "Digite o valor do produto: ";
    cin >> valorproduto_recebido;
    return valorproduto_recebido;
}

int recebe_parcelas_cliente() {
    int parcelas_recebido;
    cout << "Digite o n�mero de parcelas: ";
    cin >> parcelas_recebido;
    return parcelas_recebido;
}


int recebe_numerocartao_cliente() {
    int numerocartao_recebido;
    cout << "Digite o n�mero do cart�o: ";
    cin >> numerocartao_recebido;
    return numerocartao_recebido;
}



