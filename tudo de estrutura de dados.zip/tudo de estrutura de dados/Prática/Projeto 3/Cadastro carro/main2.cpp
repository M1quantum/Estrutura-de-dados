#include <iostream>
#include <string>
#include <stdlib.h>
#include <locale>

using namespace std;

string recebe_nome_cliente();
string recebe_sobrenome_cliente();
string recebe_cpf_cliente();
string recebe_nomeproduto_cliente();
string recebe_marcaproduto_cliente();
float recebe_valorproduto_cliente();
int recebe_parcelas_cliente();
int recebe_numerocartao_cliente();








int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");
    struct cadastro {
        string nome;
        string sobrenome;
        string cpf;
        string nomeproduto;
        string marcaproduto;
        float valorproduto;
        int parcelas;
        float valorparcelas;
        int numerocartao;
    };

    struct cadastro vetor_cliente;

    vetor_cliente.nome = recebe_nome_cliente();
    vetor_cliente.sobrenome = recebe_sobrenome_cliente();
    vetor_cliente.cpf = recebe_cpf_cliente();
    vetor_cliente.nomeproduto = recebe_nomeproduto_cliente();
    vetor_cliente.marcaproduto = recebe_marcaproduto_cliente();
    vetor_cliente.valorproduto = recebe_valorproduto_cliente();
    vetor_cliente.parcelas = recebe_parcelas_cliente();
    vetor_cliente.numerocartao = recebe_numerocartao_cliente();
    
    cout << endl;
    
    cout << "Nome = " << vetor_cliente.nome << endl;
    cout << "Sobrenome = " << vetor_cliente.sobrenome << endl;
    cout << "Cpf = " << vetor_cliente.cpf << endl;
    cout << "Produto = " << vetor_cliente.nomeproduto << endl;
    cout << "Marca do produto = " << vetor_cliente.marcaproduto << endl;
     
	 if(vetor_cliente.parcelas <= 12){
      cout << "Quantas vezes ser� dividida a parcela = " << vetor_cliente.parcelas << endl;
}else{
	cout << "N�o � permitido parcelar acima de doze vezes. A compra foi cancelada \n";
	vetor_cliente.valorproduto= 0;
	vetor_cliente.valorparcelas = 0;
}
    
    cout << "Valor do produto = " << vetor_cliente.valorproduto << endl;  
    vetor_cliente.valorparcelas = (vetor_cliente.valorproduto / vetor_cliente.parcelas);
    cout << "Valor de cada parcela = " << vetor_cliente.valorparcelas << endl;
    cout << "N�mero do cart�o = " << vetor_cliente.numerocartao << endl;
	
    
    
    
    
    return 0;
}


string recebe_nome_cliente(){
    string nome_recebido;
    cout << "Digite o nome do cliente: ";
    cin >> nome_recebido;
    return nome_recebido;
}

string recebe_sobrenome_cliente(){
    string sobrenome_recebido;
    cout << "Digite o sobrenome do cliente: ";
    cin >> sobrenome_recebido;
    return sobrenome_recebido;

}

string recebe_cpf_cliente(){
    string cpf_recebido;
    cout << "Digite o CPF do cliente: ";
    cin >> cpf_recebido;
    return cpf_recebido;

}

string recebe_nomeproduto_cliente(){
    string nomeproduto_recebido;
    cout << "Digite o produto a ser comprado: ";
    cin >> nomeproduto_recebido;
    return nomeproduto_recebido;

}

string recebe_marcaproduto_cliente(){
    string marcaproduto_recebido;
    cout << "Digite a marca do produto a ser comprado: ";
    cin >> marcaproduto_recebido;
    return marcaproduto_recebido;

}

float recebe_valorproduto_cliente() {
    float valorproduto_recebido;
    cout << "Digite o valor do produto: ";
    cin >> valorproduto_recebido;
    return valorproduto_recebido;
}

int recebe_parcelas_cliente() {
    int parcelas_recebido;
    cout << "Digite o n�mero de parcelas: ";
    cin >> parcelas_recebido;
    return parcelas_recebido;
}


int recebe_numerocartao_cliente() {
    int numerocartao_recebido;
    cout << "Digite o n�mero do cart�o: ";
    cin >> numerocartao_recebido;
    return numerocartao_recebido;
}



