#include <iostream>
#include <locale>

using namespace std;

int soma(int n) {
    if ((n==1) || (n==0)){
        return 1;
    } else {
        return soma(n-1)+n;
    }
}

int main () {
	setlocale(LC_ALL, "Portuguese");
	
	
	
	
    int n;
    cout << "Informe o n�mero que deseja obter a soma fatorial:" << endl;
    cin >> n;
    cout << "A soma fatorial de " << n << " � " << soma(n) << ". Sua soma vai de 1 a " << n << endl;
}
