#include <iostream>
#include <locale>
using namespace std;

typedef struct Cliente {
    int senha;
    int idade;
    string nome;
    int quantidade_itens;
    float valor;
} CLIENTE;

struct Node {
    CLIENTE cliente;
    Node *next;
};

struct Fila {
    Node *inicio;
    Node *final;
    int tamanho;
    int proxima_senha;
};

void inicializar(Fila *);
void entrada_cliente(Fila *, string,int,int,float);
CLIENTE saida_cliente(Fila *);
void mostraFila(Fila *);
void dados_primeiro_fila(Fila *);
void dados_ultimo_fila(Fila *);
void encerrar(Fila *);

void buscar_clientes_senha(Fila *, int);
void buscar_clientes_menores_idade(Fila *);
void buscar_clientes_melhor_idade(Fila *);
void buscar_clientes_valores_quantidades(Fila *, int);
void buscar_clientes_valores_compras(Fila *, float);

int main() {
	setlocale(LC_ALL, "Portuguese");
    Fila fila_caixa; 
    CLIENTE atendido;
    inicializar(&fila_caixa);
    entrada_cliente(&fila_caixa, "Cliente Teste 1", 20, 1, 15.5);
    entrada_cliente(&fila_caixa, "Cliente Teste 2", 40, 2, 27.25);
    entrada_cliente(&fila_caixa, "Cliente Teste 3", 18, 6, 141.39);
    entrada_cliente(&fila_caixa, "Cliente Teste 4", 65, 8, 151.39);
    
    mostraFila(&fila_caixa);
    dados_primeiro_fila(&fila_caixa);
    dados_ultimo_fila(&fila_caixa);
    
    atendido = saida_cliente(&fila_caixa);
    atendido = saida_cliente(&fila_caixa);
    atendido = saida_cliente(&fila_caixa);

    dados_primeiro_fila(&fila_caixa);
    dados_ultimo_fila(&fila_caixa);
    mostraFila(&fila_caixa);
    atendido = saida_cliente(&fila_caixa);
    dados_primeiro_fila(&fila_caixa);
    dados_ultimo_fila(&fila_caixa);
    mostraFila(&fila_caixa);
    atendido = saida_cliente(&fila_caixa);


    entrada_cliente(&fila_caixa, "Jose da Silva", 16, 1, 95.98);
    entrada_cliente(&fila_caixa, "Gabriel Nunes", 40, 2, 50.38);
    entrada_cliente(&fila_caixa, "Enrico Barros", 17, 6, 78.30);
    entrada_cliente(&fila_caixa, "Luiz Felipe Peixoto", 28, 12, 184.95);
    entrada_cliente(&fila_caixa, "Gustavo Henrique Novaes", 68, 3, 141.39);
    entrada_cliente(&fila_caixa, "Ana Luiza Rezende", 65, 5, 180.86);
    entrada_cliente(&fila_caixa, "Maria Julia da Paz", 12, 10, 23.22);
    entrada_cliente(&fila_caixa, "Jo�o Felipe Caldeira", 35, 2, 141.39);
    entrada_cliente(&fila_caixa, "Ana Campos", 27, 12, 22.38);
    entrada_cliente(&fila_caixa, "Luiz Felipe da Mota", 33, 1, 55.78);
    entrada_cliente(&fila_caixa, "Danilo Campos", 75, 2, 82.17);
    entrada_cliente(&fila_caixa, "Ana J�lia da Cunha", 72, 15, 186.69);
    entrada_cliente(&fila_caixa, "Brenda Moura", 17, 5, 64.89);
    mostraFila(&fila_caixa);

    // Busca por idades
    cout << "\t Busca por Idades " << endl;
    cout << "\t ================" << endl;
    buscar_clientes_menores_idade(&fila_caixa); 
    buscar_clientes_melhor_idade(&fila_caixa); 
    cout << endl;
    
    //  Busca por valores m�nimos gasto 
    cout << "\t Busca por Gastos M�nimos " << endl;
    cout << "\t ========================" << endl;
    buscar_clientes_valores_compras(&fila_caixa, 90); 
    buscar_clientes_valores_compras(&fila_caixa, 150); 
    cout << endl;
    //  Busca por quantidades 
    cout << "\t Busca por quantidades " << endl;
    cout << "\t =====================" << endl;
    buscar_clientes_valores_quantidades(&fila_caixa, 5);
    buscar_clientes_valores_quantidades(&fila_caixa, 10);
    cout << endl;

    //  Busca por senha 
    cout << "\t Busca por senha " << endl;
    cout << "\t ===============" << endl;
    buscar_clientes_senha(&fila_caixa, 3);
    buscar_clientes_senha(&fila_caixa, 10);
    cout << endl;

    encerrar(&fila_caixa);
    mostraFila(&fila_caixa);
    
    return 0;
}

void inicializar(Fila *fila) {
    fila->tamanho = 0;
    fila->proxima_senha = 1;
    fila->inicio = NULL;
    fila->final = NULL;
}

CLIENTE saida_cliente(Fila *fila) {
    CLIENTE retorno;
    Node* aux;
    if (fila->final != NULL) {
        if ( fila->inicio != fila->final) {
            aux = fila->inicio;
            fila->inicio = fila->inicio->next;
            retorno = aux->cliente;
            aux->next = NULL;
            delete aux;
            fila->tamanho = fila->tamanho - 1; 
        } else {
            retorno = fila->final->cliente;
            aux = fila->final;
            delete aux;
            fila->inicio = NULL;
            fila->final = NULL;
            fila->tamanho = fila->tamanho - 1; 
        }
    } else {
        retorno.senha = -1;
        retorno.nome = "";
        retorno.idade = -1;
        retorno.valor = -1;
    }
    return retorno;
}

void entrada_cliente(Fila *fila, string nome, int idade, int quantidade_itens, float valor){
    Node *new_node = new Node;
    if (new_node == NULL) {
        cerr << "Acabou a mem�ria. " << endl; 
        exit(1);
    }
    new_node->cliente.senha = fila->proxima_senha;
    new_node->cliente.nome = nome;
    new_node->cliente.idade = idade;
    new_node->cliente.quantidade_itens = quantidade_itens;
    new_node->cliente.valor = valor;
    new_node->next = NULL;
    fila->proxima_senha = fila->proxima_senha + 1;
    if (fila->inicio == NULL) {
        fila->inicio = new_node;
        fila->final = new_node;
    } else {
        Node* aux = fila->inicio;
        while(aux->next != NULL){
            aux = aux->next;    
        }
        aux->next = new_node;
        fila->final = new_node; 
    }
    fila->tamanho = fila->tamanho + 1; 
}

void mostraFila(Fila *fila){
    if (fila->inicio != NULL) {
        cout << "Tamanho da fila: " << fila->tamanho << endl;
        Node* cliente_local = fila->inicio;
        while(cliente_local->next != NULL){
            cout <<"[" << cliente_local->cliente.senha << "-";
            cout << cliente_local->cliente.nome << "] -> ";
            cliente_local = cliente_local->next;
        }
        cout <<"[" << cliente_local->cliente.senha << "-";
        cout << cliente_local->cliente.nome << "]";
        cout << endl << endl;
    } else {
        cout << "Tamanho da fila: " << fila->tamanho << endl;
        cout << "[]" << endl;
    }
}

void dados_primeiro_fila(Fila *fila){
    if (fila->inicio != NULL) {
        cout << "Pr�ximo ser�: \t \t" << fila->inicio->cliente.senha << "  -  ";
        cout << fila->inicio->cliente.nome << "  -  ";
        cout << fila->inicio->cliente.idade << " anos  -  ";
        cout << fila->inicio->cliente.quantidade_itens << "  -  ";
        cout << "R$ " << fila->inicio->cliente.valor;
        cout << endl << endl;
    }
}

void dados_ultimo_fila(Fila *fila){
    if (fila->inicio != NULL) {    
        cout << "�ltimo da fila:  \t" << fila->final->cliente.senha << "  -  ";
        cout << fila->final->cliente.nome << "  -  ";
        cout << fila->final->cliente.idade << " anos  -  ";
        cout << fila->inicio->cliente.quantidade_itens << "  -  ";
        cout << "R$ " << fila->final->cliente.valor;
        cout << endl << endl;
    }
}

void encerrar(Fila *fila){
    if (fila->inicio != NULL) { 
        while(fila->inicio->next != NULL){
            saida_cliente(fila);
        }
        saida_cliente(fila);
    }
}

/* Desenvolver suas fun��es a partir deste ponto. */
void buscar_clientes_senha(Fila *fila, int senha) {
    Node *atual = fila->inicio;
    bool encontrado = false;

    while (atual != NULL) {
        if (atual->cliente.senha == senha) {
            cout << "[SENHA: " << atual->cliente.senha << " - NOME =  " << atual->cliente.nome << "]";
            encontrado = true;
            break;
        }
        atual = atual->next;
    }

    if (!encontrado) {
        cout << "Cliente n�o localizado" << endl;
    }
    cout << endl;
}


void buscar_clientes_menores_idade(Fila *fila) {
    Node *atual = fila->inicio;
    bool encontrado = false;

    while (atual != NULL) {
        if (atual->cliente.idade < 18) {
            cout << "[" << atual->cliente.nome << " - " << atual->cliente.idade << " anos]";
            encontrado = true;
        }
        atual = atual->next;
    }

    if (!encontrado) {
        cout << "Nenhum cliente menor de 18 anos encontrado" << endl;
    }
    cout << endl;
}



void buscar_clientes_melhor_idade(Fila *fila) {
    Node *atual = fila->inicio;
    bool encontrado = false;

    while (atual != NULL) {
        if (atual->cliente.idade > 65) {
            cout << "[" << atual->cliente.nome << " - " << atual->cliente.idade << " anos]";
            encontrado = true;
        }
        atual = atual->next;
    }

    if (!encontrado) {
        cout << "Nenhum cliente com idade superior a 65 anos encontrado" << endl;
    }
    
    cout << endl;
}



void buscar_clientes_valores_quantidades(Fila *fila, int quantidade) {
    Node *atual = fila->inicio;
    bool encontrado = false;

    while (atual != NULL) {
        if (atual->cliente.quantidade_itens > quantidade) {
            cout << "[" << atual->cliente.nome << " - qtd = " << atual->cliente.quantidade_itens << "]";
            encontrado = true;
        }
        atual = atual->next;
    }

    if (!encontrado) {
        cout << "Nenhum cliente com quantidade de itens superior a " << quantidade << " encontrado" << endl;
    }
    cout << endl;
}


void buscar_clientes_valores_compras(Fila *fila, float valor_compra) {
    Node *atual = fila->inicio;
    bool encontrado = false;

    while (atual != NULL) {
        if (atual->cliente.valor > valor_compra) {
            cout << "[" << atual->cliente.nome << " - R$ " << atual->cliente.valor << "]";
            encontrado = true;
        }
        atual = atual->next;
    }

    if (!encontrado) {
        cout << "Nenhum cliente com valor de compra superior a R$ " << valor_compra << " encontrado" << endl;
    }
    cout << endl;
}
