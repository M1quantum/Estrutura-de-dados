#include <iostream>
#include <string>
#include <stdlib.h>
#include <locale>

using namespace std;

static int TOTAL = 0;

string recebe_nome_cliente();
string recebe_sobrenome_cliente();
string recebe_cpf_cliente();
string recebe_nomeproduto_cliente();
string recebe_marcaproduto_cliente();
float recebe_valorproduto_cliente();
int recebe_parcelas_cliente();
int recebe_numerocartao_cliente();








int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");
    struct cadastroCliente{
        string nome;
        string sobrenome;
        string cpf;
        string nomeproduto;
        string marcaproduto;
        float valorproduto;
        int parcelas;
        float valorparcelas;
        int numerocartao;
    };
    
    int x;
    cadastroCliente cliente;
    cadastroCliente *vetor_cliente;
    
    cout << "Digite o numero de elementos: " << endl;
    cin >> TOTAL;
    
    vetor_cliente = new cadastroCliente[TOTAL];
    
    for(x = 0; x < TOTAL; x++) {
        cout << "Digite o nome do cliente " <<  x+1 << ": " << endl;
        cin >> vetor_cliente[x].nome;
        cout << "Digite o sobrenome do cliente " << x+1 << ": " << endl;
        cin >> vetor_cliente[x].sobrenome;
        cout << "Digite o CPF  do cliente " << x+1 << ": " << endl;
        cin >> vetor_cliente[x].cpf;
        cout << "Digite o produto a ser comprado " << ": " << endl;
        cin >> vetor_cliente[x].nomeproduto;
        cout << "Digite a marca do produto a ser comprado " << ": " << endl;
        cin >> vetor_cliente[x].marcaproduto;
        cout << "Digite o valor do produto a ser comprado " << ": " << endl;
        cin >> vetor_cliente[x].valorproduto;
        cout << "Digite o numero de parcelas " << ": " << endl;
        cin >> vetor_cliente[x].parcelas;
        cout << "Digite o numero do cartao " << ": " << endl;
        cin >> vetor_cliente[x].numerocartao;
    }
    
     cout << "\n ********************** " << endl;
     
     
    for ( x = 0; x<TOTAL; x++) {
    if(vetor_cliente[x].parcelas <= 12){
    
    cout << "Quantidade de parcelas que vai dividir = " << vetor_cliente[x].parcelas << endl;
    cout << "Nome = " << vetor_cliente[x].nome << endl;
    cout << "Sobrenome = " << vetor_cliente[x].sobrenome << endl;
    cout << "Cpf = " << vetor_cliente[x].cpf << endl;
    cout << "Produto = " << vetor_cliente[x].nomeproduto << endl;
    cout << "Marca do produto = " << vetor_cliente[x].marcaproduto << endl; 
	cout << "N�mero do cart�o = " << vetor_cliente[x].numerocartao << endl;   
    cout << "Valor do produto = " << vetor_cliente[x].valorproduto << endl;  
    vetor_cliente[x].valorparcelas = (vetor_cliente[x].valorproduto / vetor_cliente[x].parcelas);
    cout << "Valor de cada parcela = " << vetor_cliente[x].valorparcelas << endl;
}else{
	cout << "N�o � permitido parcelar acima de doze vezes. A compra do produto " << vetor_cliente[x].nomeproduto << " foi cancelada \n";
  }
  cout << endl;
}
	
    
    delete[] vetor_cliente;
    
    
    
    return 0;
}
