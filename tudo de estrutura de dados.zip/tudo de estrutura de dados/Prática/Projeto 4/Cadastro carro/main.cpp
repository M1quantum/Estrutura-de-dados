#include <iostream>
#include <locale>
#include <string>

using namespace std;

static int contador = 0;

int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");

    int x;

    struct CadastroCarro {;
        float preco;
        string marcaproduto;
        string nomeproduto;
        int parcelas;
        float valorparcelas;
        string placacarro;
    };

    CadastroCarro carro;
    CadastroCarro *vetor_carros;

    cout << " Digite o n�mero de elementos: " << endl;
    cin >> contador;

    vetor_carros = new CadastroCarro[contador];

    /*    Entrada de dados    */
    for(x = 0; x < contador; x++) {
        cout << "Digite a marca do produto " <<  x+1 << ": " << endl;
        cin >> vetor_carros[x].marcaproduto;
        cout << "Digite o nome do produto " <<  x+1 << ": " << endl;
        cin >> vetor_carros[x].nomeproduto;
        cout << "Digite o pre�o do produto " <<  x+1 << ": " << endl;
        cin >> vetor_carros[x].preco;
        cout << "Digite o a placa produto " <<  x+1 << ": " << endl;
        cin >> vetor_carros[x].placacarro;
        cout << "Digite o n�mero de parcelas " <<  x+1 << ": " << endl;
        cin >> vetor_carros[x].parcelas;
    }

    cout << "\n ********************** " << endl;
    /* Imprimir resultados  */
    for(x = 0; x < contador; x++) {
    	cout << endl;
        cout << "A marca do carro:\t " << vetor_carros[x].marcaproduto << endl;
        cout << "O nome do carro:\t " << vetor_carros[x].nomeproduto << endl;
        cout << "O pre�o do carro:\t " << vetor_carros[x].marcaproduto << endl;
        cout << "Valor de cada parcela:\t " << ( vetor_carros[x].preco / vetor_carros[x].parcelas );
        cout << endl;
    }
    
    cout << "\n ********************** " << endl;


    delete[] vetor_carros;

    return 0;
}
