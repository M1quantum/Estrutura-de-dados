#include <iostream>
#include <locale>
using namespace std;




int main() {
	setlocale(LC_ALL, "Portuguese");
	int n, r, soma=0;
	
	cout << " Digite o n�mero a ser fatorado em  soma: ";
	cin >> n; 
	
	while(r<=n){
		soma += r;
		r++;
	}
	
	cout <<  "A soma fatorial de " << n << " � " << soma << ". Sua soma fatorada vai de 1 a " << n << endl;
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
