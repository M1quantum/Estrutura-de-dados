/*
Ponteiro Vazio - .

Prof. Me. Orlando Saraiva Jr
*/

#include <iostream>
#include <locale>

using namespace std;

int main(int argc, char *argv[]){
	setlocale(LC_ALL, "Portuguese");
    int a = 20;
    float b = 4.5;
    string c = "Oi Mundo";
    void *ptr;

    ptr=&a;
    cout << "O valor de *ptr � " << *( (int*) ptr) << endl;

    ptr=&b;
    cout << "O valor de *ptr � " << *( (float*) ptr) << endl;

    ptr=&c;
    cout << "O valor de *ptr � " << *( (string*) ptr) << endl;
    return 0;
}
